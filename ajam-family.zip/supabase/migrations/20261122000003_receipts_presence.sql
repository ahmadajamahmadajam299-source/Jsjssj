-- Delivery / read receipts. Server functions only; clients never write receipts directly for others.
create function public.mark_delivered() returns void
language sql security definer set search_path = public as $$
  insert into public.message_receipts (message_id, user_id, delivered_at)
  select m.id, auth.uid(), now()
  from public.messages m
  join public.conversation_members cm
    on cm.conversation_id = m.conversation_id and cm.user_id = auth.uid()
  where m.sender_id <> auth.uid() and m.created_at > now() - interval '7 days'
  on conflict (message_id, user_id) do nothing;
$$;

create function public.mark_read(p_conv uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_member(p_conv) then return; end if;
  insert into public.message_receipts (message_id, user_id, delivered_at, read_at)
  select m.id, auth.uid(), now(), now()
  from public.messages m
  where m.conversation_id = p_conv and m.sender_id <> auth.uid()
    and not exists (select 1 from public.message_receipts r
                    where r.message_id = m.id and r.user_id = auth.uid() and r.read_at is not null)
  on conflict (message_id, user_id) do update
    set read_at = coalesce(public.message_receipts.read_at, now()),
        delivered_at = coalesce(public.message_receipts.delivered_at, now());
  update public.conversation_members set last_read_at = now()
   where conversation_id = p_conv and user_id = auth.uid();
end $$;

create function public.get_receipts(p_conv uuid)
returns table (msg_id uuid, is_delivered boolean, is_read boolean)
language plpgsql stable security definer set search_path = public as $$
declare others int;
begin
  if not public.is_member(p_conv) then return; end if;
  select count(*) into others from public.conversation_members cm
   where cm.conversation_id = p_conv and cm.user_id <> auth.uid();
  return query
    select m.id,
      others > 0 and (select count(*) from public.message_receipts r
                      where r.message_id = m.id and r.delivered_at is not null) >= others,
      others > 0 and (select count(*) from public.message_receipts r
                      where r.message_id = m.id and r.read_at is not null) >= others
    from public.messages m
    where m.conversation_id = p_conv and m.sender_id = auth.uid()
    order by m.created_at desc limit 200;
end $$;

grant execute on function public.mark_delivered(), public.mark_read(uuid), public.get_receipts(uuid) to authenticated;
