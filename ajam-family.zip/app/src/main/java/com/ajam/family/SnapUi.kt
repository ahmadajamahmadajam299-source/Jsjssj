package com.ajam.family

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.ColorMatrix as AndroidColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Path as AndroidPath
import android.net.Uri
import android.view.WindowManager
import android.widget.VideoView
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshot.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.ByteArrayOutputStream
import java.io.File
import kotlin.math.roundToInt

private fun has(ctx: android.content.Context, perm: String) =
    ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED

@Composable
fun SecureWindow() {
    val ctx = LocalContext.current
    DisposableEffect(Unit) {
        val w = (ctx as? Activity)?.window
        w?.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        onDispose { w?.clearFlags(WindowManager.LayoutParams.FLAG_SECURE) }
    }
}

// ================= camera tab =================
@Composable
fun CameraTab(fvm: FeaturesVm) {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(has(ctx, Manifest.permission.CAMERA)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = has(ctx, Manifest.permission.CAMERA)
    }
    LaunchedEffect(Unit) {
        if (!granted) launcher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
    }
    if (!granted) {
        Column(
            Modifier.fillMaxSize().padding(32.dp),
            verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("📷", fontSize = 64.sp)
            Spacer(Modifier.height(12.dp))
            Text("نحتاج إذن الكاميرا لالتقاط السنابات", textAlign = TextAlign.Center)
            Spacer(Modifier.height(12.dp))
            Button(onClick = { launcher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)) }) { Text("السماح") }
        }
        return
    }
    CameraContent(fvm)
}

@Composable
private fun CameraContent(fvm: FeaturesVm) {
    val ctx = LocalContext.current
    val owner = ctx as LifecycleOwner
    val previewView = remember { PreviewView(ctx).apply { scaleType = PreviewView.ScaleType.FILL_CENTER } }
    var front by remember { mutableStateOf(false) }
    var flash by remember { mutableStateOf(false) }
    var camera by remember { mutableStateOf<Camera?>(null) }
    var recording by remember { mutableStateOf<Recording?>(null) }
    var recSeconds by remember { mutableStateOf(0) }
    val imageCapture = remember { ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build() }
    val recorder = remember {
        Recorder.Builder()
            .setQualitySelector(QualitySelector.from(Quality.HD, FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)))
            .build()
    }
    val videoCapture = remember { VideoCapture.withOutput(recorder) }
    val executor = remember { ContextCompat.getMainExecutor(ctx) }

    DisposableEffect(front) {
        val future = ProcessCameraProvider.getInstance(ctx)
        future.addListener({
            try {
                val provider = future.get()
                provider.unbindAll()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val sel = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                camera = try {
                    provider.bindToLifecycle(owner, sel, preview, imageCapture, videoCapture)
                } catch (e: Exception) {
                    provider.unbindAll()
                    provider.bindToLifecycle(owner, sel, preview, imageCapture)
                }
            } catch (e: Exception) {
                fvm.error = "تعذر تشغيل الكاميرا"
            }
        }, executor)
        onDispose { try { future.get().unbindAll() } catch (e: Exception) { } }
    }
    LaunchedEffect(flash) {
        imageCapture.flashMode = if (flash) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF
    }
    LaunchedEffect(recording) {
        if (recording != null) {
            recSeconds = 0
            repeat(15) { delay(1000); recSeconds++ }
            recording?.stop()
        }
    }

    fun takePhoto() {
        val file = File(ctx.cacheDir, "snap_${System.currentTimeMillis()}.jpg")
        imageCapture.takePicture(
            ImageCapture.OutputFileOptions.Builder(file).build(), executor,
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) { fvm.captured = Captured(file, false) }
                override fun onError(exception: ImageCaptureException) { fvm.error = "تعذر التقاط الصورة" }
            }
        )
    }

    fun startVideo() {
        if (recording != null) return
        val file = File(ctx.cacheDir, "snap_${System.currentTimeMillis()}.mp4")
        try {
            var pending = recorder.prepareRecording(ctx, FileOutputOptions.Builder(file).build())
            if (has(ctx, Manifest.permission.RECORD_AUDIO)) pending = pending.withAudioEnabled()
            recording = pending.start(executor) { ev ->
                if (ev is VideoRecordEvent.Finalize) {
                    recording = null
                    if (!ev.hasError()) fvm.captured = Captured(file, true) else fvm.error = "تعذر تسجيل الفيديو"
                }
            }
        } catch (e: Exception) {
            fvm.error = "تسجيل الفيديو غير مدعوم على هذا الجهاز"
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
        Box(
            Modifier.fillMaxSize()
                .pointerInput(camera) {
                    detectTransformGestures { _, _, zoom, _ ->
                        val c = camera ?: return@detectTransformGestures
                        val cur = c.cameraInfo.zoomState.value?.zoomRatio ?: 1f
                        c.cameraControl.setZoomRatio(cur * zoom)
                    }
                }
                .pointerInput(camera) {
                    detectTapGestures { offset ->
                        val c = camera ?: return@detectTapGestures
                        val pt = previewView.meteringPointFactory.createPoint(offset.x, offset.y)
                        c.cameraControl.startFocusAndMetering(FocusMeteringAction.Builder(pt).build())
                    }
                }
        )
        // top controls
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            RoundIcon("📥" + if (fvm.inbox.isNotEmpty()) " ${fvm.inbox.size}" else "") { fvm.overlay = Overlay.Hub }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                RoundIcon(if (flash) "⚡" else "🔦") { flash = !flash }
                RoundIcon("🔄") { front = !front }
            }
        }
        if (recording != null) {
            Text(
                "● ${recSeconds}ث / 15", color = Color.White, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 70.dp)
                    .background(Color.Red.copy(alpha = 0.8f), RoundedCornerShape(50)).padding(horizontal = 12.dp, vertical = 4.dp)
            )
        }
        Column(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("اضغط للصورة · اضغط مطولاً للفيديو (15ث)", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            Box(
                Modifier.size(82.dp).border(5.dp, if (recording != null) Color.Red else Color.White, CircleShape).padding(8.dp)
                    .clip(CircleShape).background(if (recording != null) Color.Red else Color.White.copy(alpha = 0.25f))
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onTap = { if (recording == null) takePhoto() },
                            onLongPress = { startVideo() },
                            onPress = { tryAwaitRelease(); recording?.stop() }
                        )
                    }
            )
        }
    }
}

@Composable
fun RoundIcon(text: String, onClick: () -> Unit) {
    Box(
        Modifier.height(44.dp).clip(RoundedCornerShape(22.dp)).background(Color.Black.copy(alpha = 0.45f))
            .clickable { onClick() }.padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, fontSize = 20.sp, color = Color.White) }
}

// ================= editor =================
private class Ink(val color: Int, val pts: SnapshotStateList<Offset>)

private class Sticker(val emoji: String, x: Float, y: Float) {
    var x by mutableStateOf(x)
    var y by mutableStateOf(y)
}

private val filterNames = listOf("بدون", "أبيض وأسود", "دافئ", "بارد", "زاهي", "قديم")
private fun filterMatrix(i: Int): FloatArray? = when (i) {
    1 -> floatArrayOf(0.33f, 0.59f, 0.11f, 0f, 0f, 0.33f, 0.59f, 0.11f, 0f, 0f, 0.33f, 0.59f, 0.11f, 0f, 0f, 0f, 0f, 0f, 1f, 0f)
    2 -> floatArrayOf(1.15f, 0f, 0f, 0f, 12f, 0f, 1.0f, 0f, 0f, 0f, 0f, 0f, 0.8f, 0f, -8f, 0f, 0f, 0f, 1f, 0f)
    3 -> floatArrayOf(0.85f, 0f, 0f, 0f, -6f, 0f, 1.0f, 0f, 0f, 0f, 0f, 0f, 1.2f, 0f, 14f, 0f, 0f, 0f, 1f, 0f)
    4 -> floatArrayOf(1.4f, -0.2f, -0.2f, 0f, 0f, -0.2f, 1.4f, -0.2f, 0f, 0f, -0.2f, -0.2f, 1.4f, 0f, 0f, 0f, 0f, 0f, 1f, 0f)
    5 -> floatArrayOf(0.393f, 0.769f, 0.189f, 0f, 0f, 0.349f, 0.686f, 0.168f, 0f, 0f, 0.272f, 0.534f, 0.131f, 0f, 0f, 0f, 0f, 0f, 1f, 0f)
    else -> null
}
private val inkColors = listOf(Color.White, Color.Red, Color(0xFFFFD54A), Color(0xFF2ED47A), Color(0xFF29B6F6), Color.Black)
private val emojis = listOf("😂", "😍", "🔥", "❤️", "👍", "🎉", "😎", "🥰", "😭", "🌹", "👑", "🤲")

private fun renderBitmap(
    bmp: Bitmap, filter: FloatArray?, inks: List<Ink>, stickers: List<Sticker>,
    caption: String, boxW: Float, density: Float
): ByteArray {
    val out = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
    val c = AndroidCanvas(out)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    if (filter != null) p.colorFilter = ColorMatrixColorFilter(AndroidColorMatrix(filter))
    c.drawBitmap(bmp, 0f, 0f, p)
    val k = if (boxW > 0f) bmp.width / boxW else 1f
    for (ink in inks) {
        if (ink.pts.size < 2) continue
        val sp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = ink.color; style = Paint.Style.STROKE; strokeWidth = 8f * k
            strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        }
        val path = AndroidPath()
        path.moveTo(ink.pts[0].x * k, ink.pts[0].y * k)
        for (i in 1 until ink.pts.size) path.lineTo(ink.pts[i].x * k, ink.pts[i].y * k)
        c.drawPath(path, sp)
    }
    for (s in stickers) {
        val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 48f * density * k }
        c.drawText(s.emoji, s.x * k, s.y * k + tp.textSize * 0.85f, tp)
    }
    if (caption.isNotBlank()) {
        val bandH = 90f * k
        val bg = Paint().apply { color = 0x99000000.toInt() }
        c.drawRect(0f, bmp.height * 0.8f - bandH / 2, bmp.width.toFloat(), bmp.height * 0.8f + bandH / 2, bg)
        val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.WHITE; textSize = 34f * k; textAlign = Paint.Align.CENTER
            isFakeBoldText = true
        }
        c.drawText(caption.take(80), bmp.width / 2f, bmp.height * 0.8f + tp.textSize * 0.35f, tp)
    }
    val bos = ByteArrayOutputStream()
    out.compress(Bitmap.CompressFormat.JPEG, 88, bos)
    return bos.toByteArray()
}

@Composable
fun SnapEditor(vm: AppVm, fvm: FeaturesVm, cap: Captured) {
    BackHandler { fvm.captured = null }
    val density = LocalDensity.current.density
    val scope = rememberCoroutineScope()
    var showSend by remember { mutableStateOf(false) }
    var boxW by remember { mutableStateOf(0f) }
    var filter by remember { mutableStateOf(0) }
    var mode by remember { mutableStateOf(0) } // 0 none, 1 draw, 2 text, 3 emoji
    var inkColor by remember { mutableStateOf(Color.White) }
    var caption by remember { mutableStateOf("") }
    val inks = remember { mutableStateListOf<Ink>() }
    val stickers = remember { mutableStateListOf<Sticker>() }
    val bmp = remember(cap.file) { if (cap.isVideo) null else try { Media.decodeFile(cap.file, 1600) } catch (e: Exception) { null } }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (cap.isVideo) {
            AndroidView(
                factory = { c ->
                    VideoView(c).apply {
                        setVideoURI(Uri.fromFile(cap.file))
                        setOnPreparedListener { it.isLooping = true; start() }
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        } else if (bmp != null) {
            val fm = filterMatrix(filter)
            Box(
                Modifier.align(Alignment.Center).fillMaxWidth().aspectRatio(bmp.width.toFloat() / bmp.height)
                    .onSizeChanged { boxW = it.width.toFloat() }
            ) {
                Image(
                    bmp.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds,
                    colorFilter = fm?.let { ColorFilter.colorMatrix(ColorMatrix(it)) }
                )
                Canvas(
                    Modifier.fillMaxSize().pointerInput(mode, inkColor) {
                        if (mode == 1) {
                            detectDragGestures(
                                onDragStart = { o -> inks.add(Ink(inkColor.toArgb(), mutableStateListOf(o))) },
                                onDrag = { change, _ -> change.consume(); inks.lastOrNull()?.pts?.add(change.position) }
                            )
                        }
                    }
                ) {
                    for (ink in inks) {
                        if (ink.pts.size < 2) continue
                        val path = Path().apply {
                            moveTo(ink.pts[0].x, ink.pts[0].y)
                            for (i in 1 until ink.pts.size) lineTo(ink.pts[i].x, ink.pts[i].y)
                        }
                        drawPath(path, Color(ink.color), style = Stroke(8f, cap = StrokeCap.Round, join = StrokeJoin.Round))
                    }
                }
                for (s in stickers) {
                    Text(
                        s.emoji, fontSize = 48.sp,
                        modifier = Modifier.offset { IntOffset(s.x.roundToInt(), s.y.roundToInt()) }
                            .pointerInput(Unit) {
                                detectDragGestures { change, drag -> change.consume(); s.x += drag.x; s.y += drag.y }
                            }
                    )
                }
                if (caption.isNotBlank()) {
                    Text(
                        caption, color = Color.White, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
                        modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 40.dp).fillMaxWidth()
                            .background(Color.Black.copy(alpha = 0.55f)).padding(8.dp)
                    )
                }
            }
        } else {
            Text("تعذر فتح الصورة", color = Color.White, modifier = Modifier.align(Alignment.Center))
        }

        // top bar
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
        ) {
            RoundIcon("✕") { fvm.captured = null }
            if (!cap.isVideo) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    RoundIcon("✏️") { mode = if (mode == 1) 0 else 1 }
                    RoundIcon("Aa") { mode = if (mode == 2) 0 else 2 }
                    RoundIcon("😀") { mode = if (mode == 3) 0 else 3 }
                    RoundIcon("↩") { if (inks.isNotEmpty()) inks.removeAt(inks.lastIndex) else if (stickers.isNotEmpty()) stickers.removeAt(stickers.lastIndex) }
                }
            }
        }
        // bottom tools
        Column(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(12.dp)) {
            if (cap.isVideo) {
                Text("تعديل الفيديو غير متاح بعد، يُرسل كما هو.", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
            } else {
                when (mode) {
                    1 -> Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        inkColors.forEach { c ->
                            Box(
                                Modifier.size(32.dp).clip(CircleShape).background(c)
                                    .border(if (c == inkColor) 3.dp else 1.dp, Color.White, CircleShape)
                                    .clickable { inkColor = c }
                            )
                        }
                    }
                    2 -> OutlinedTextField(
                        value = caption, onValueChange = { caption = it.take(80) }, singleLine = true,
                        placeholder = { Text("اكتب تعليقاً") }, modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp)
                    )
                    3 -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        emojis.take(7).forEach { e ->
                            Text(e, fontSize = 28.sp, modifier = Modifier.clickable { stickers.add(Sticker(e, boxW / 2 - 40f, 200f)) })
                        }
                    }
                    else -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        filterNames.forEachIndexed { i, n ->
                            Box(
                                Modifier.clip(RoundedCornerShape(50))
                                    .background(if (i == filter) Color.White else Color.Black.copy(alpha = 0.5f))
                                    .clickable { filter = i }.padding(horizontal = 12.dp, vertical = 6.dp)
                            ) { Text(n, color = if (i == filter) Color.Black else Color.White, fontSize = 12.sp) }
                        }
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Button(onClick = { showSend = true }, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(16.dp)) {
                Text("التالي  ➜", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            }
        }
    }

    if (showSend) {
        SendDialog(vm, fvm, onDismiss = { showSend = false }) { recipients, story, seconds ->
            if (cap.isVideo) {
                fvm.sendCapturedVideo(cap.file, recipients, story, seconds)
            } else if (bmp != null) {
                scope.launch {
                    val bytes = withContext(Dispatchers.Default) {
                        renderBitmap(bmp, filterMatrix(filter), inks.toList(), stickers.toList(), caption, boxW, density)
                    }
                    fvm.sendSnap(bytes, false, recipients, story, seconds)
                }
            }
            showSend = false
        }
    }
    if (fvm.sending) {
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.6f)), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Color.White)
        }
    }
}

@Composable
private fun SendDialog(vm: AppVm, fvm: FeaturesVm, onDismiss: () -> Unit, onSend: (List<String>, Boolean, Int?) -> Unit) {
    val picked = remember { mutableStateListOf<String>() }
    val pickedGroups = remember { mutableStateListOf<String>() }
    var story by remember { mutableStateOf(false) }
    var seconds by remember { mutableStateOf<Int?>(5) }
    val others = vm.members.filter { it.id != vm.me?.id && it.status == "active" }
    val groups = vm.convs.filter { it.isGroup }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إرسال إلى") },
        text = {
            LazyColumn(Modifier.height(380.dp)) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { story = !story }) {
                        Checkbox(story, { story = it }); Text("📖 قصتي (24 ساعة)")
                    }
                }
                items(others, key = { "u" + it.id }) { p ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(p.id in picked, { on -> if (on) picked.add(p.id) else picked.remove(p.id) })
                        Text(p.displayName)
                    }
                }
                items(groups, key = { "g" + it.id }) { g ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(g.id in pickedGroups, { on -> if (on) pickedGroups.add(g.id) else pickedGroups.remove(g.id) })
                        Text("👥 " + g.title)
                    }
                }
                item {
                    Spacer(Modifier.height(8.dp))
                    Text("مدة العرض", fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(1, 3, 5, 10, null).forEach { s ->
                            val sel = seconds == s
                            Box(
                                Modifier.clip(RoundedCornerShape(50))
                                    .background(if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                                    .clickable { seconds = s }.padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    if (s == null) "بلا حد" else "${s}ث", fontSize = 12.sp,
                                    color = if (sel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                    Text("يُعرض مرتين كحد أقصى (مرة وإعادة واحدة).", fontSize = 11.sp)
                }
            }
        },
        confirmButton = {
            val ids = (picked.toList() + pickedGroups.flatMap { vm.groupMemberIds[it] ?: emptyList() }).distinct()
            TextButton(enabled = ids.isNotEmpty() || story, onClick = { onSend(ids, story, seconds) }) { Text("إرسال") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

// ================= hub: inbox / streaks / score =================
@Composable
fun SnapsHub(vm: AppVm, fvm: FeaturesVm) {
    BackHandler { fvm.overlay = Overlay.None }
    var tab by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) { fvm.refreshSocial(); fvm.loadScores() }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Row(
            Modifier.fillMaxWidth().background(BrandBrush).statusBarsPadding().padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = { fvm.overlay = Overlay.None }) { Text("✕", color = Color.White, fontSize = 20.sp) }
            Text("السنابات", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("📥 الوارد", "🔥 السلاسل", "🏆 عجم سكور").forEachIndexed { i, t ->
                if (tab == i) Button(onClick = { tab = i }) { Text(t) } else OutlinedButton(onClick = { tab = i }) { Text(t) }
            }
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
            when (tab) {
                0 -> {
                    if (fvm.inbox.isEmpty()) item { Text("لا توجد سنابات جديدة 📭", Modifier.padding(24.dp)) }
                    items(fvm.inbox, key = { it.snapId }) { s ->
                        val p = vm.profileOf(s.senderId)
                        Row(
                            Modifier.fillMaxWidth().clickable { fvm.overlay = Overlay.ViewSnap(s) }.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            UserAvatar(vm, p, p?.displayName ?: "؟", 48)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(p?.displayName ?: "", fontWeight = FontWeight.Bold)
                                Text(
                                    (if (s.kind == "video") "🎬 فيديو" else "📸 صورة") +
                                        if (s.viewCount >= 1) " · إعادة (مرة واحدة)" else " · جديد",
                                    fontSize = 12.sp
                                )
                            }
                        }
                        HorizontalDivider()
                    }
                }
                1 -> {
                    if (fvm.streaks.isEmpty()) item {
                        Text("لا توجد سلاسل بعد. تبادل السنابات مع أحد أفراد العائلة كل يوم لتبدأ 🔥", Modifier.padding(24.dp))
                    }
                    items(fvm.streaks, key = { it.otherId }) { st ->
                        val p = vm.profileOf(st.otherId)
                        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            UserAvatar(vm, p, p?.displayName ?: "؟", 48)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(p?.displayName ?: "", fontWeight = FontWeight.Bold)
                                Text(
                                    if (st.iSent && st.theySent) "تبادلتما اليوم ✓"
                                    else if (st.iSent) "بانتظار سناب منه" else "أرسل له سناباً للحفاظ على السلسلة",
                                    fontSize = 12.sp
                                )
                            }
                            Text((if (st.warn) "⏳ " else "") + "🔥 ${st.dayCount}", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        }
                        HorizontalDivider()
                    }
                }
                else -> {
                    items(fvm.leaderboard.size) { i ->
                        val r = fvm.leaderboard[i]
                        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                when (i) { 0 -> "🥇"; 1 -> "🥈"; 2 -> "🥉"; else -> "${i + 1}" },
                                fontSize = 22.sp, modifier = Modifier.width(40.dp)
                            )
                            UserAvatar(vm, vm.profileOf(r.userId), r.displayName, 44)
                            Spacer(Modifier.width(12.dp))
                            Text(r.displayName + if (r.userId == vm.me?.id) " (أنت)" else "", Modifier.weight(1f), fontWeight = FontWeight.Bold)
                            Text("${r.points}", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        }
                        HorizontalDivider()
                    }
                }
            }
        }
        Text(
            "عجم سكور: +1 لكل سناب ترسله، +1 لكل سناب تفتحه، +2 لكل ستوري، ومكافآت للسلاسل 7/30/100 يوم.",
            Modifier.padding(12.dp), fontSize = 11.sp
        )
    }
}

// ================= snap viewer =================
@Composable
fun SnapViewer(vm: AppVm, fvm: FeaturesVm, s: InboxSnap) {
    SecureWindow()
    val close = { fvm.overlay = Overlay.None; fvm.refreshSocial() }
    BackHandler { close() }
    val scope = rememberCoroutineScope()
    var url by remember { mutableStateOf<String?>(null) }
    var held by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var remainingMs by remember { mutableStateOf((s.viewSeconds ?: 0) * 1000) }
    val total = (s.viewSeconds ?: 0) * 1000

    LaunchedEffect(held, url) {
        if (held && url != null && s.viewSeconds != null) {
            while (remainingMs > 0) { delay(100); remainingMs -= 100 }
            close()
        }
    }

    Box(
        Modifier.fillMaxSize().background(Color.Black)
            .pointerInput(Unit) {
                detectTapGestures(onPress = {
                    val quick = withTimeoutOrNull(300) { tryAwaitRelease() }
                    if (quick == null) {
                        held = true
                        if (url == null && !loading) {
                            loading = true
                            scope.launch {
                                try { url = fvm.openSnapUrl(s.snapId) } catch (e: Exception) {
                                    fvm.error = "هذا السناب لم يعد متاحاً"; close()
                                }
                            }
                        }
                        tryAwaitRelease()
                        held = false
                        if (url != null) close()
                    }
                })
            },
        contentAlignment = Alignment.Center
    ) {
        val u = url
        if (held && u != null) {
            if (s.kind == "photo") {
                AsyncImage(u, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            } else {
                AndroidView(
                    factory = { c ->
                        VideoView(c).apply {
                            setVideoURI(Uri.parse(u))
                            setOnPreparedListener { it.start() }
                            setOnCompletionListener { close() }
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
            if (s.viewSeconds != null && total > 0) {
                LinearProgressIndicator(
                    progress = { remainingMs.toFloat() / total },
                    modifier = Modifier.fillMaxWidth().statusBarsPadding().padding(8.dp)
                )
            }
        } else {
            val p = vm.profileOf(s.senderId)
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                UserAvatar(vm, p, p?.displayName ?: "؟", 80)
                Spacer(Modifier.height(16.dp))
                Text(
                    if (loading) "جارٍ التحميل..." else "اضغط باستمرار لعرض السناب",
                    color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold
                )
                Text(
                    if (s.viewCount >= 1) "هذه آخر مشاهدة (إعادة)" else "يمكن إعادة مشاهدته مرة واحدة فقط",
                    color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp
                )
            }
        }
        TextButton(onClick = { close() }, modifier = Modifier.align(Alignment.TopStart).statusBarsPadding()) {
            Text("✕", color = Color.White, fontSize = 22.sp)
        }
    }
}

// ================= stories =================
@Composable
fun StoriesTab(vm: AppVm, fvm: FeaturesVm, goCamera: () -> Unit) {
    val byUser = fvm.stories.groupBy { it.userId }
    val myId = vm.me?.id
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Row(
                Modifier.fillMaxWidth().clickable { if (byUser[myId] != null) fvm.overlay = Overlay.ViewStories(myId!!) else goCamera() }.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box {
                    UserAvatar(vm, vm.me, vm.me?.displayName ?: "؟", 56)
                    Box(
                        Modifier.align(Alignment.BottomEnd).size(22.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary)
                            .clickable { goCamera() },
                        contentAlignment = Alignment.Center
                    ) { Text("+", color = Color.White, fontWeight = FontWeight.Bold) }
                }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text("قصتي", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text(if (byUser[myId] != null) "${byUser[myId]!!.size} عنصر · اضغط للمشاهدة" else "أضف ستوري يختفي بعد 24 ساعة", fontSize = 12.sp)
                }
            }
            HorizontalDivider()
        }
        val others = byUser.filterKeys { it != myId }
        if (others.isEmpty()) item { Text("لا توجد ستوريات من العائلة الآن 🌙", Modifier.padding(24.dp)) }
        items(others.entries.toList(), key = { it.key }) { (uid, list) ->
            val p = vm.profileOf(uid)
            val unseen = list.any { !it.viewed }
            Row(
                Modifier.fillMaxWidth().clickable { fvm.overlay = Overlay.ViewStories(uid) }.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.clip(CircleShape).border(
                        3.dp, if (unseen) Color(0xFF2ED47A) else Color.Gray, CircleShape
                    ).padding(3.dp)
                ) { UserAvatar(vm, p, p?.displayName ?: "؟", 52) }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text(p?.displayName ?: "", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text("${list.size} عنصر" + if (unseen) " · جديد" else "", fontSize = 12.sp)
                }
            }
            HorizontalDivider()
        }
    }
}

@Composable
fun StoryViewer(vm: AppVm, fvm: FeaturesVm, userId: String) {
    val close = { fvm.overlay = Overlay.None; fvm.refreshSocial() }
    BackHandler { close() }
    val items = fvm.stories.filter { it.userId == userId }
    if (items.isEmpty()) { LaunchedEffect(Unit) { close() }; return }
    var idx by remember { mutableStateOf(0) }
    val cur = items[idx.coerceIn(0, items.lastIndex)]
    val mine = userId == vm.me?.id
    val p = vm.profileOf(userId)
    var reply by remember { mutableStateOf("") }
    var viewers by remember { mutableStateOf<List<Viewer>?>(null) }
    var progress by remember { mutableStateOf(0f) }
    LaunchedEffect(cur.storyId) {
        vm.ensureUrl("snaps", cur.mediaPath)
        if (!mine) fvm.viewStory(cur.storyId)
        progress = 0f
        if (cur.kind == "photo") {
            val steps = 50
            for (i in 1..steps) { delay(100); progress = i / steps.toFloat() }
            if (idx < items.lastIndex) idx++ else close()
        }
    }
    val url = vm.urls["snaps:${cur.mediaPath}"]
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (url != null) {
            if (cur.kind == "photo") {
                AsyncImage(url, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            } else {
                AndroidView(
                    factory = { c ->
                        VideoView(c).apply {
                            setVideoURI(Uri.parse(url))
                            setOnPreparedListener { it.start() }
                            setOnCompletionListener { if (idx < items.lastIndex) idx++ else close() }
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
        } else {
            CircularProgressIndicator(Modifier.align(Alignment.Center), color = Color.White)
        }
        // tap zones
        Row(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f).fillMaxHeight().clickable(indication = null, interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }) {
                if (idx < items.lastIndex) idx++ else close()
            })
            Box(Modifier.weight(1f).fillMaxHeight().clickable(indication = null, interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }) {
                if (idx > 0) idx-- else close()
            })
        }
        Column(Modifier.fillMaxWidth().statusBarsPadding().padding(8.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                items.forEachIndexed { i, _ ->
                    LinearProgressIndicator(
                        progress = { if (i < idx) 1f else if (i == idx) progress else 0f },
                        modifier = Modifier.weight(1f).height(3.dp)
                    )
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
                UserAvatar(vm, p, p?.displayName ?: "؟", 36)
                Spacer(Modifier.width(8.dp))
                Text(p?.displayName ?: "", color = Color.White, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { close() }) { Text("✕", color = Color.White, fontSize = 20.sp) }
            }
        }
        Column(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(12.dp)) {
            if (mine) {
                Button(onClick = { viewers = emptyList() }, modifier = Modifier.fillMaxWidth()) { Text("👁 المشاهدون") }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        reply, { reply = it.take(200) }, placeholder = { Text("رد على الستوري") },
                        modifier = Modifier.weight(1f), singleLine = true, shape = RoundedCornerShape(24.dp)
                    )
                    TextButton(enabled = reply.isNotBlank(), onClick = { fvm.replyToStory(userId, reply); reply = "" }) { Text("إرسال") }
                }
            }
        }
    }
    if (viewers != null) {
        LaunchedEffect(cur.storyId) { viewers = fvm.viewers(cur.storyId) }
        AlertDialog(
            onDismissRequest = { viewers = null },
            confirmButton = { TextButton(onClick = { viewers = null }) { Text("حسناً") } },
            title = { Text("المشاهدون") },
            text = {
                Column {
                    if (viewers!!.isEmpty()) Text("لا أحد شاهدها بعد")
                    viewers!!.forEach { v -> Text("• " + vm.nameOf(v.viewerId)) }
                }
            }
        )
    }
}
