package com.ajam.family

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.OffsetDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

// ---------- brand ----------
val BrandBrush = Brush.linearGradient(listOf(Color(0xFF083D3A), Color(0xFF0B6B5A), Color(0xFF16B07F)))
val BubbleBrush = Brush.linearGradient(listOf(Color(0xFF0A5E50), Color(0xFF0F8F6D)))
val Online = Color(0xFF2ED47A)
val TickBlue = Color(0xFF53BDEB)
private val avatarColors = listOf(
    Color(0xFF0F8F6D), Color(0xFF7C4DFF), Color(0xFFFF7043), Color(0xFF29B6F6),
    Color(0xFFEC407A), Color(0xFFFFA000), Color(0xFF26A69A), Color(0xFF5C6BC0)
)

@Composable
fun pulse(from: Float = 0.92f, to: Float = 1.08f, ms: Int = 900): Float {
    val t = rememberInfiniteTransition(label = "pulse")
    val v by t.animateFloat(
        initialValue = from, targetValue = to,
        animationSpec = infiniteRepeatable(tween(ms, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulseValue"
    )
    return v
}

@Composable
fun Appear(delayMs: Int = 0, content: @Composable () -> Unit) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(delayMs.toLong())
        visible = true
    }
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(500)) + slideInVertically(tween(500)) { it / 3 }
    ) { content() }
}

@Composable
fun LogoMark(size: Dp) {
    Box(
        Modifier.size(size).clip(CircleShape)
            .background(Brush.linearGradient(listOf(Color(0xFF083D3A), Color(0xFF16B07F))))
            .border(2.dp, Color.White.copy(alpha = 0.55f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Image(painterResource(R.drawable.ic_fg), null, Modifier.size(size * 1.5f), contentScale = ContentScale.Fit)
    }
}

// ---------- root ----------
@Composable
fun AppRoot(vm: AppVm = viewModel()) {
    var splashDone by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(2600)
        splashDone = true
    }
    val showSplash = !splashDone || vm.stage == Stage.Loading
    Box(Modifier.fillMaxSize()) {
        Crossfade(targetState = showSplash, animationSpec = tween(500), label = "splash") { s ->
            if (s) SplashScreen() else Content(vm)
        }
        if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth().statusBarsPadding())
    }
    vm.error?.let { msg ->
        AlertDialog(
            onDismissRequest = { vm.error = null },
            confirmButton = { TextButton(onClick = { vm.error = null }) { Text("حسناً") } },
            title = { Text("تنبيه") },
            text = { Text(msg) }
        )
    }
}

@Composable
private fun Content(vm: AppVm) {
    when (vm.stage) {
        Stage.Loading -> Box(Modifier.fillMaxSize())
        Stage.Welcome -> WelcomeScreen(vm)
        Stage.Username -> UsernameScreen(vm)
        Stage.Tour -> TourScreen(vm)
        Stage.FamilyGate -> FamilyGateScreen(vm)
        Stage.Pending -> PendingScreen(vm)
        Stage.Main -> if (vm.openChat != null) ChatScreen(vm) else MainScreen(vm)
    }
}

@Composable
fun SplashScreen() {
    val scale = remember { Animatable(0.2f) }
    val alpha = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        launch { scale.animateTo(1f, spring(dampingRatio = 0.45f, stiffness = Spring.StiffnessLow)) }
        launch { alpha.animateTo(1f, tween(1100)) }
    }
    val ring = pulse(1f, 1.4f, 1300)
    Box(Modifier.fillMaxSize().background(BrandBrush), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(contentAlignment = Alignment.Center) {
                Box(Modifier.size(150.dp).scale(ring).alpha(0.14f).background(Color.White, CircleShape))
                Box(Modifier.scale(scale.value)) { LogoMark(120.dp) }
            }
            Spacer(Modifier.height(28.dp))
            Text(
                "عائلة العجم", color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.alpha(alpha.value)
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "صُنع بحب بواسطة أحمد العجم", color = Color.White.copy(alpha = 0.85f), fontSize = 15.sp,
                modifier = Modifier.alpha(alpha.value)
            )
        }
    }
}

// ---------- auth frame ----------
@Composable
fun AuthFrame(title: String, subtitle: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().background(BrandBrush).imePadding()) {
        Column(
            Modifier.weight(1f).fillMaxWidth().statusBarsPadding().padding(horizontal = 24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Appear { LogoMark(88.dp) }
            Spacer(Modifier.height(16.dp))
            Appear(150) { Text(title, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center) }
            Spacer(Modifier.height(6.dp))
            Appear(250) { Text(subtitle, color = Color.White.copy(alpha = 0.88f), textAlign = TextAlign.Center) }
        }
        Appear(300) {
            Surface(
                shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.navigationBarsPadding().padding(24.dp), content = content)
            }
        }
    }
}

@Composable
fun BigButton(text: String, enabled: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick, enabled = enabled, shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth().height(52.dp)
    ) { Text(text, fontSize = 17.sp, fontWeight = FontWeight.Bold) }
}

@Composable
fun WelcomeScreen(vm: AppVm) {
    var name by remember { mutableStateOf("") }
    AuthFrame("ما اسمك؟", "أهلاً بك في عائلة العجم.\nاكتب اسمك وادخل مباشرة.") {
        OutlinedTextField(
            value = name, onValueChange = { name = it.take(40) },
            label = { Text("اكتب اسمك") }, singleLine = true,
            shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(16.dp))
        BigButton("متابعة", name.trim().isNotEmpty() && !vm.busy) { vm.submitName(name) }
    }
}

@Composable
fun UsernameScreen(vm: AppVm) {
    var u by remember { mutableStateOf("") }
    LaunchedEffect(u) {
        vm.resetUsernameCheck()
        if (u.length >= 3) {
            delay(400)
            vm.checkUsername(u)
        }
    }
    AuthFrame("اختر اسم المستخدم", "أحرف إنجليزية صغيرة وأرقام و _ و . فقط.\nالاسم دائم ولا يمكن تغييره أبداً.") {
        OutlinedTextField(
            value = u,
            onValueChange = { s ->
                u = s.lowercase().filter { c -> c in 'a'..'z' || c in '0'..'9' || c == '_' || c == '.' }.take(24)
            },
            label = { Text("اسم المستخدم") }, singleLine = true,
            shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(6.dp))
        val (status, color) = when {
            u.isEmpty() -> "" to MaterialTheme.colorScheme.onSurface
            u.length < 3 -> "٣ أحرف على الأقل" to MaterialTheme.colorScheme.onSurface
            vm.usernameOk == true -> "متاح ✓" to Online
            vm.usernameOk == false -> "محجوز، اختر غيره" to MaterialTheme.colorScheme.error
            else -> "جارٍ التحقق..." to MaterialTheme.colorScheme.onSurface
        }
        Text(status, color = color, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        BigButton("تأكيد الاسم", vm.usernameOk == true && !vm.busy) { vm.claimUsername(u) }
    }
}

// ---------- tour ----------
private data class Slide(val emoji: String, val title: String, val body: String, val soon: Boolean)

@Composable
fun TourScreen(vm: AppVm) {
    val slides = remember {
        listOf(
            Slide("💬", "دردشة العائلة", "محادثات فردية ومجموعات، مع علامة ✓✓ تتحول للأزرق عندما يقرأ الشخص رسالتك، وحالة «متصل الآن».", false),
            Slide("📸", "سنابات وستوري", "صوّر وأرسل سناب لأحبابك وضع ستوري يختفي بعد 24 ساعة.", true),
            Slide("🔥", "عجم سكور", "نقاطك وسلاسل الأيام مع أصدقائك، ولوحة ترتيب لكل العائلة.", true),
            Slide("📍", "خريطة العائلة", "شاهد أين كل فرد من العائلة مباشرة، مع وضع الخصوصية متى شئت.", true),
            Slide("📞", "مكالمات", "مكالمات صوت وفيديو فردية وجماعية داخل العائلة.", true)
        )
    }
    val pager = rememberPagerState { slides.size }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().background(BrandBrush).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(8.dp)) {
            TextButton(onClick = { vm.finishTour() }) { Text("تخطّي", color = Color.White) }
        }
        HorizontalPager(pager, Modifier.weight(1f)) { page -> SlideView(slides[page]) }
        Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.Center) {
            slides.indices.forEach { i ->
                val sel = pager.currentPage == i
                val w by animateDpAsState(if (sel) 26.dp else 8.dp, tween(300), label = "dot")
                val c by animateColorAsState(if (sel) Color.White else Color.White.copy(alpha = 0.4f), tween(300), label = "dotc")
                Box(Modifier.padding(horizontal = 3.dp).height(8.dp).width(w).clip(CircleShape).background(c))
            }
        }
        Box(Modifier.padding(24.dp)) {
            Button(
                onClick = {
                    if (pager.currentPage < slides.lastIndex) scope.launch { pager.animateScrollToPage(pager.currentPage + 1) }
                    else vm.finishTour()
                },
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text(if (pager.currentPage < slides.lastIndex) "التالي" else "ابدأ", fontSize = 17.sp, fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
private fun SlideView(s: Slide) {
    val bounce = pulse(-14f, 14f, 1100)
    val glow = pulse(0.9f, 1.15f, 1400)
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(contentAlignment = Alignment.Center) {
            Box(Modifier.size(190.dp).scale(glow).background(Color.White.copy(alpha = 0.12f), CircleShape))
            Text(s.emoji, fontSize = 92.sp, modifier = Modifier.graphicsLayer { translationY = bounce })
        }
        Spacer(Modifier.height(32.dp))
        Text(s.title, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(12.dp))
        Text(s.body, color = Color.White.copy(alpha = 0.9f), fontSize = 16.sp, textAlign = TextAlign.Center)
        if (s.soon) {
            Spacer(Modifier.height(16.dp))
            Surface(shape = RoundedCornerShape(50), color = Color(0xFFFFD54A)) {
                Text("قريباً", Modifier.padding(horizontal = 14.dp, vertical = 4.dp), color = Color(0xFF3B2F00), fontWeight = FontWeight.Bold)
            }
        }
    }
}

// ---------- family gate ----------
@Composable
fun FamilyGateScreen(vm: AppVm) {
    var mode by remember { mutableStateOf(0) }
    var text by remember { mutableStateOf("") }
    AuthFrame("عائلتك", "أول من ينشئ العائلة يصبح المدير،\nوالباقون ينضمون بالكود.") {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (mode == 0) Button(onClick = { mode = 0; text = "" }) { Text("إنشاء عائلة") }
            else OutlinedButton(onClick = { mode = 0; text = "" }) { Text("إنشاء عائلة") }
            if (mode == 1) Button(onClick = { mode = 1; text = "" }) { Text("الانضمام بكود") }
            else OutlinedButton(onClick = { mode = 1; text = "" }) { Text("الانضمام بكود") }
        }
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = text,
            onValueChange = { text = if (mode == 1) it.uppercase().take(8) else it.take(60) },
            label = { Text(if (mode == 0) "اسم العائلة" else "كود العائلة") },
            singleLine = true, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        BigButton(if (mode == 0) "إنشاء" else "انضمام", text.trim().isNotEmpty() && !vm.busy) {
            if (mode == 0) vm.createFamily(text) else vm.joinFamily(text)
        }
    }
}

@Composable
fun PendingScreen(vm: AppVm) {
    LaunchedEffect(Unit) {
        while (true) {
            delay(4000)
            vm.silentRefresh()
        }
    }
    val s = pulse(0.85f, 1.15f, 900)
    AuthFrame("بانتظار الموافقة", "مدير العائلة سيقبل طلبك،\nويفتح التطبيق تلقائياً بعد القبول.") {
        Box(Modifier.fillMaxWidth().padding(8.dp), contentAlignment = Alignment.Center) {
            Text("⏳", fontSize = 56.sp, modifier = Modifier.scale(s))
        }
    }
}

// ---------- main ----------
@Composable
fun AppHeader(title: String) {
    Row(
        Modifier.fillMaxWidth().background(BrandBrush).statusBarsPadding().padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        LogoMark(34.dp)
        Spacer(Modifier.width(10.dp))
        Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun MainScreen(vm: AppVm) {
    var tab by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(5000)
            vm.silentReload()
        }
    }
    val titles = listOf("المحادثات", "العائلة", "حسابي")
    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = { AppHeader(titles[tab]) },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Filled.Chat, null) }, label = { Text("المحادثات") })
                NavigationBarItem(tab == 1, { tab = 1 }, { Icon(Icons.Filled.Group, null) }, label = { Text("العائلة") })
                NavigationBarItem(tab == 2, { tab = 2 }, { Icon(Icons.Filled.Person, null) }, label = { Text("حسابي") })
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            AnimatedContent(
                targetState = tab,
                transitionSpec = { fadeIn(tween(250)) togetherWith fadeOut(tween(150)) },
                label = "tabs"
            ) { t ->
                when (t) {
                    0 -> ChatsTab(vm)
                    1 -> FamilyTab(vm)
                    else -> ProfileTab(vm)
                }
            }
        }
    }
}

@Composable
fun Avatar(name: String, size: Int = 46, online: Boolean = false) {
    val color = avatarColors[(name.hashCode() and 0x7fffffff) % avatarColors.size]
    Box(contentAlignment = Alignment.BottomEnd) {
        Box(
            Modifier.size(size.dp).clip(CircleShape).background(Brush.linearGradient(listOf(color, color.copy(alpha = 0.7f)))),
            contentAlignment = Alignment.Center
        ) {
            Text(name.trim().take(1), color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size / 2.2).sp)
        }
        if (online) {
            Box(
                Modifier.size((size / 3.4).dp).background(Online, CircleShape)
                    .border(2.dp, MaterialTheme.colorScheme.surface, CircleShape)
            )
        }
    }
}

private fun parseInstant(s: String?): Instant? = try {
    if (s == null) null else OffsetDateTime.parse(s).toInstant()
} catch (e: Exception) { null }

fun isOnline(p: Profile?): Boolean {
    val t = parseInstant(p?.lastSeenAt) ?: return false
    return Duration.between(t, Instant.now()).seconds < 50
}

fun presenceText(p: Profile?): String {
    if (p == null) return ""
    if (isOnline(p)) return "متصل الآن"
    if (p.hideLastSeen) return ""
    val t = parseInstant(p.lastSeenAt) ?: return ""
    val z = t.atZone(ZoneId.systemDefault())
    val time = z.format(DateTimeFormatter.ofPattern("HH:mm"))
    return if (z.toLocalDate() == LocalDate.now()) "آخر ظهور اليوم $time"
    else "آخر ظهور " + z.format(DateTimeFormatter.ofPattern("dd/MM")) + " $time"
}

@Composable
fun ChatsTab(vm: AppVm) {
    var showGroup by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize()) {
        if (vm.convs.isEmpty()) {
            Column(
                Modifier.fillMaxSize().padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("💬", fontSize = 64.sp, modifier = Modifier.scale(pulse(0.9f, 1.1f, 1000)))
                Spacer(Modifier.height(12.dp))
                Text("لا توجد محادثات بعد", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Text("افتح تبويب «العائلة» واضغط على أي فرد لبدء محادثة.", textAlign = TextAlign.Center)
            }
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(vm.convs, key = { it.id }) { c ->
                    val other = vm.profileOf(c.otherId)
                    Row(
                        Modifier.fillMaxWidth().clickable { vm.open(c) }.padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Avatar(c.title, 52, online = !c.isGroup && isOnline(other))
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text(c.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            val sub = if (c.isGroup) "مجموعة" else presenceText(other)
                            if (sub.isNotEmpty()) {
                                Text(
                                    sub, style = MaterialTheme.typography.bodySmall,
                                    color = if (sub == "متصل الآن") Online else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                )
                            }
                        }
                    }
                    HorizontalDivider(Modifier.padding(start = 82.dp))
                }
            }
        }
        FloatingActionButton(
            onClick = { showGroup = true },
            containerColor = MaterialTheme.colorScheme.primary,
            modifier = Modifier.align(Alignment.BottomStart).padding(16.dp)
        ) { Icon(Icons.Filled.Add, "مجموعة جديدة") }
    }
    if (showGroup) NewGroupDialog(vm) { showGroup = false }
}

@Composable
fun NewGroupDialog(vm: AppVm, onClose: () -> Unit) {
    var name by remember { mutableStateOf("") }
    val picked = remember { mutableStateListOf<String>() }
    val others = vm.members.filter { it.id != vm.me?.id && it.status == "active" }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("مجموعة جديدة") },
        text = {
            Column {
                OutlinedTextField(name, { name = it.take(60) }, label = { Text("اسم المجموعة") }, singleLine = true)
                Spacer(Modifier.height(8.dp))
                LazyColumn(Modifier.height(240.dp)) {
                    items(others, key = { it.id }) { p ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(p.id in picked, { on -> if (on) picked.add(p.id) else picked.remove(p.id) })
                            Text(p.displayName)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.trim().isNotEmpty() && picked.isNotEmpty(),
                onClick = { vm.createGroup(name, picked.toList()); onClose() }
            ) { Text("إنشاء") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("إلغاء") } }
    )
}

@Composable
fun FamilyTab(vm: AppVm) {
    val ctx = LocalContext.current
    val isAdmin = vm.me?.role == "admin"
    val pending = vm.members.filter { it.status == "pending" }
    val active = vm.members.filter { it.status == "active" }
    LazyColumn(Modifier.fillMaxSize()) {
        if (isAdmin) {
            item {
                Card(Modifier.fillMaxWidth().padding(16.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("كود العائلة", style = MaterialTheme.typography.titleSmall)
                        Text(vm.joinCode ?: "...", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = {
                                val i = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, "انضم لعائلتنا في تطبيق عائلة العجم بالكود: ${vm.joinCode}")
                                }
                                ctx.startActivity(Intent.createChooser(i, "مشاركة الكود"))
                            }) { Text("مشاركة") }
                            OutlinedButton(onClick = { vm.newCode() }) { Text("كود جديد") }
                        }
                    }
                }
            }
            if (pending.isNotEmpty()) {
                item { Text("طلبات الانضمام", Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.titleSmall) }
                items(pending, key = { "p" + it.id }) { p ->
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Avatar(p.displayName)
                        Spacer(Modifier.width(12.dp))
                        Text(p.displayName, Modifier.weight(1f))
                        Button(onClick = { vm.approve(p.id) }) { Text("قبول") }
                        TextButton(onClick = { vm.remove(p.id) }) { Text("رفض") }
                    }
                }
            }
        }
        item { Text("أفراد العائلة", Modifier.padding(16.dp), style = MaterialTheme.typography.titleSmall) }
        items(active, key = { "a" + it.id }) { p ->
            val mine = p.id == vm.me?.id
            Row(
                Modifier.fillMaxWidth().clickable(enabled = !mine) { vm.startDirect(p.id) }.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Avatar(p.displayName, 50, online = mine || isOnline(p))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(p.displayName + if (mine) " (أنت)" else "", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("@" + (p.username ?: "") + if (p.role == "admin") " · مدير" else "", style = MaterialTheme.typography.bodySmall)
                    val pr = if (mine) "" else presenceText(p)
                    if (pr.isNotEmpty()) Text(pr, style = MaterialTheme.typography.bodySmall, color = if (pr == "متصل الآن") Online else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                }
                if (isAdmin && !mine) {
                    if (p.role != "admin") TextButton(onClick = { vm.promote(p.id) }) { Text("ترقية") }
                    TextButton(onClick = { vm.remove(p.id) }) { Text("إزالة") }
                }
            }
            HorizontalDivider()
        }
    }
}

@Composable
fun ProfileTab(vm: AppVm) {
    val me = vm.me
    var name by remember(me?.displayName) { mutableStateOf(me?.displayName ?: "") }
    var bio by remember(me?.bio) { mutableStateOf(me?.bio ?: "") }
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Appear { Avatar(name.ifBlank { "؟" }, 96, online = true) }
        Spacer(Modifier.height(8.dp))
        Text("@" + (me?.username ?: ""), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(name, { name = it.take(40) }, label = { Text("الاسم") }, singleLine = true, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(bio, { bio = it.take(120) }, label = { Text("الحالة") }, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("إخفاء «آخر ظهور»", Modifier.weight(1f))
            Switch(checked = me?.hideLastSeen == true, onCheckedChange = { vm.setHideLastSeen(it) })
        }
        Spacer(Modifier.height(12.dp))
        BigButton("حفظ", name.trim().isNotEmpty() && !vm.busy) { vm.saveProfile(name, bio) }
    }
}

// ---------- chat ----------
private fun timeOf(iso: String): String = try {
    OffsetDateTime.parse(iso).atZoneSameInstant(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("HH:mm"))
} catch (e: Exception) { "" }

@Composable
fun Ticks(delivered: Boolean, read: Boolean) {
    val color by animateColorAsState(
        if (read) TickBlue else Color.White.copy(alpha = 0.75f), tween(500), label = "tick"
    )
    Text(if (delivered || read) "✓✓" else "✓", color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold)
}

@Composable
fun ChatScreen(vm: AppVm) {
    val chat = vm.openChat ?: return
    BackHandler { vm.closeChat() }
    var text by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    LaunchedEffect(chat.id) {
        while (true) {
            vm.pollMessages()
            delay(2500)
        }
    }
    LaunchedEffect(vm.messages.size) {
        if (vm.messages.isNotEmpty()) listState.animateScrollToItem(vm.messages.lastIndex)
    }
    val other = vm.profileOf(chat.otherId)
    val bg = Brush.verticalGradient(listOf(MaterialTheme.colorScheme.background, MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)))
    Column(Modifier.fillMaxSize().background(bg).navigationBarsPadding().imePadding()) {
        Row(
            Modifier.fillMaxWidth().background(BrandBrush).statusBarsPadding().padding(horizontal = 8.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { vm.closeChat() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع", tint = Color.White) }
            Avatar(chat.title, 40, online = !chat.isGroup && isOnline(other))
            Spacer(Modifier.width(10.dp))
            Column {
                Text(chat.title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                val sub = if (chat.isGroup) "مجموعة" else presenceText(other)
                if (sub.isNotEmpty()) Text(sub, color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
            }
        }
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(), state = listState,
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp)
        ) {
            itemsIndexed(vm.messages, key = { _, m -> m.id }) { index, m ->
                val mine = m.senderId == vm.me?.id
                val isLast = index == vm.messages.lastIndex
                val state = remember { MutableTransitionState(!isLast).apply { targetState = true } }
                val r = vm.receipts[m.id]
                AnimatedVisibility(
                    visibleState = state,
                    enter = fadeIn(tween(250)) + scaleIn(tween(250), initialScale = 0.85f) + slideInVertically(tween(250)) { it / 2 }
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 2.dp),
                        horizontalArrangement = if (mine) Arrangement.Start else Arrangement.End
                    ) {
                        val shape = RoundedCornerShape(18.dp)
                        val bubbleMod = if (mine) Modifier.clip(shape).background(BubbleBrush)
                        else Modifier.clip(shape).background(MaterialTheme.colorScheme.surfaceVariant)
                        Column(bubbleMod.widthIn(max = 290.dp).padding(horizontal = 12.dp, vertical = 7.dp)) {
                            if (!mine && chat.isGroup) {
                                Text(vm.nameOf(m.senderId), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            }
                            Text(m.body ?: "", color = if (mine) Color.White else MaterialTheme.colorScheme.onSurface, fontSize = 16.sp)
                            Row(Modifier.align(Alignment.End), verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    timeOf(m.createdAt), fontSize = 11.sp,
                                    color = if (mine) Color.White.copy(alpha = 0.75f) else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f)
                                )
                                if (mine) {
                                    Spacer(Modifier.width(4.dp))
                                    Ticks(r?.first == true, r?.second == true)
                                }
                            }
                        }
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = text, onValueChange = { text = it.take(4000) },
                placeholder = { Text("اكتب رسالة") }, shape = RoundedCornerShape(24.dp),
                modifier = Modifier.weight(1f), maxLines = 4
            )
            Spacer(Modifier.width(8.dp))
            val canSend = text.trim().isNotEmpty()
            val sc by animateFloatAsStateCompat(canSend)
            Box(
                Modifier.size(50.dp).scale(sc).clip(CircleShape).background(if (canSend) BubbleBrush else Brush.linearGradient(listOf(Color.Gray, Color.Gray)))
                    .clickable(enabled = canSend) { vm.send(text); text = "" },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.AutoMirrored.Filled.Send, "إرسال", tint = Color.White) }
        }
    }
}

@Composable
private fun animateFloatAsStateCompat(active: Boolean) =
    androidx.compose.animation.core.animateFloatAsState(if (active) 1f else 0.9f, spring(dampingRatio = 0.5f), label = "send")
