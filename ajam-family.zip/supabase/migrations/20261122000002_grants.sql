-- Newer Supabase projects no longer auto-grant table privileges to API roles.
-- Row-level security still decides which rows each user can touch.
grant usage on schema public to authenticated;

grant select on public.profiles to authenticated;
grant select on public.conversations to authenticated;
grant select on public.conversation_members to authenticated;
grant select, insert on public.messages to authenticated;
grant select, insert, update on public.message_receipts to authenticated;
grant select, insert, update, delete on public.message_reactions to authenticated;
grant select, insert, delete on public.message_stars to authenticated;
grant select, insert, delete on public.blocks to authenticated;
grant select, insert on public.reports to authenticated;

grant execute on function public.my_family_id(), public.is_family_admin(),
  public.is_member(uuid), public.is_conv_admin(uuid) to authenticated;
