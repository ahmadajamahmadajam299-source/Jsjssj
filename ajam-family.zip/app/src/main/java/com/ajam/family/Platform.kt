package com.ajam.family

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** Process-wide flag set by MainActivity (true while the UI is visible). */
object AppState {
    @Volatile var foreground = false
}

object Notifs {
    const val CH_CONN = "conn"
    const val CH_LOC = "loc"
    const val CH_MSG = "msg"
    const val CH_CALL = "call"
    const val CH_SOS = "sos"
    const val ID_CALL = 1001
    const val ID_SOS = 1002

    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_CONN, "الاتصال بالعائلة", NotificationManager.IMPORTANCE_MIN))
        nm.createNotificationChannel(NotificationChannel(CH_LOC, "مشاركة الموقع", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_MSG, "الرسائل", NotificationManager.IMPORTANCE_HIGH))
        val ring = NotificationChannel(CH_CALL, "المكالمات", NotificationManager.IMPORTANCE_HIGH).apply {
            setSound(
                RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE),
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE).build()
            )
            enableVibration(true)
        }
        nm.createNotificationChannel(ring)
        val sos = NotificationChannel(CH_SOS, "تنبيه الطوارئ SOS", NotificationManager.IMPORTANCE_HIGH).apply {
            setSound(
                RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build()
            )
            enableVibration(true)
        }
        nm.createNotificationChannel(sos)
    }

    fun openApp(ctx: Context, code: Int): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(ctx, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    fun post(ctx: Context, id: Int, n: Notification) {
        try { NotificationManagerCompat.from(ctx).notify(id, n) } catch (e: SecurityException) { }
    }

    fun cancel(ctx: Context, id: Int) { NotificationManagerCompat.from(ctx).cancel(id) }
}

object LocationHelper {
    fun hasPermission(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun hasBackground(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 29 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    fun lastKnown(ctx: Context): Location? {
        if (!hasPermission(ctx)) return null
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        var best: Location? = null
        for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)) {
            val l = try { lm.getLastKnownLocation(p) } catch (e: Exception) { null }
            if (l != null && (best == null || l.time > best.time)) best = l
        }
        return best
    }

    fun startSharing(ctx: Context) {
        ContextCompat.startForegroundService(ctx, Intent(ctx, LocationService::class.java))
    }

    fun stopSharing(ctx: Context) { ctx.stopService(Intent(ctx, LocationService::class.java)) }
}

class LocationService : Service(), LocationListener {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var lm: LocationManager
    private var interval = 20_000L
    private var stillCount = 0
    private var started = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Notifs.ensureChannels(this)
        val n = NotificationCompat.Builder(this, Notifs.CH_LOC)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("مشاركة الموقع مع العائلة")
            .setContentText("موقعك يُشارك الآن. أوقفه من تبويب الخريطة.")
            .setOngoing(true)
            .setContentIntent(Notifs.openApp(this, 2))
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        } else {
            startForeground(2, n)
        }
        lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        if (!started) { started = true; register() }
        return START_STICKY
    }

    @SuppressLint("MissingPermission")
    private fun register() {
        if (!LocationHelper.hasPermission(this)) { stopSelf(); return }
        try {
            lm.removeUpdates(this)
            for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
                if (lm.isProviderEnabled(p)) lm.requestLocationUpdates(p, interval, 0f, this, Looper.getMainLooper())
            }
        } catch (e: Exception) { }
    }

    override fun onLocationChanged(loc: Location) {
        val speed = if (loc.hasSpeed()) loc.speed else 0f
        val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val status = bi?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        scope.launch {
            try {
                Repo.awaitInit()
                if (Repo.hasSession()) Api.updateLocation(loc.latitude, loc.longitude, loc.accuracy, speed, pct, charging)
            } catch (e: CancellationException) { throw e } catch (e: Exception) { }
        }
        // Adaptive interval: frequent when moving, rare when still.
        val next = when {
            speed > 2.5f -> 10_000L
            speed > 0.7f -> 20_000L
            else -> { stillCount++; if (stillCount >= 3) 120_000L else 30_000L }
        }
        if (speed > 0.7f) stillCount = 0
        if (next != interval) { interval = next; register() }
    }

    @Deprecated("Required on API < 30")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}

    override fun onDestroy() {
        try { lm.removeUpdates(this) } catch (e: Exception) { }
        scope.cancel()
        super.onDestroy()
    }
}

class ConnectionService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private val notifiedMsg = HashMap<String, String>()
    private val notifiedSos = HashSet<String>()
    private var lastCall: String? = null
    private var names: Map<String, String> = emptyMap()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Notifs.ensureChannels(this)
        val n = NotificationCompat.Builder(this, Notifs.CH_CONN)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("عائلة العجم متصل")
            .setContentText("لاستقبال المكالمات والرسائل وتنبيهات الطوارئ")
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .setContentIntent(Notifs.openApp(this, 1))
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
        if (job == null) job = scope.launch { loop() }
        return START_STICKY
    }

    private suspend fun nameOf(id: String): String {
        names[id]?.let { return it }
        names = try { Repo.members().associate { it.id to it.displayName } } catch (e: Exception) { names }
        return names[id] ?: "أحد أفراد العائلة"
    }

    private suspend fun loop() {
        try { Repo.awaitInit() } catch (e: Exception) { }
        while (scope.isActive) {
            try {
                if (Repo.hasSession()) {
                    val fg = AppState.foreground
                    if (!fg) {
                        val call = Api.incomingCall()
                        if (call != null) {
                            if (call.id != lastCall) { lastCall = call.id; notifyCall(call) }
                        } else {
                            lastCall = null
                            Notifs.cancel(this, Notifs.ID_CALL)
                        }
                        for (u in Api.unread()) {
                            val last = u.lastMsgId ?: continue
                            if (!u.muted && notifiedMsg[u.convId] != last) {
                                notifiedMsg[u.convId] = last
                                notifyMsg(u)
                            }
                        }
                        val me = Repo.uid()
                        for (s in Api.activeSos()) {
                            if (s.userId != me && notifiedSos.add(s.id)) notifySos(s)
                        }
                    } else {
                        Notifs.cancel(this, Notifs.ID_CALL)
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) { }
            delay(if (AppState.foreground) 8_000L else 4_000L)
        }
    }

    private suspend fun notifyCall(c: IncomingCall) {
        val who = nameOf(c.callerId)
        val pi = Notifs.openApp(this, 10)
        val n = NotificationCompat.Builder(this, Notifs.CH_CALL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(who)
            .setContentText(if (c.kind == "video") "مكالمة فيديو واردة" else "مكالمة صوتية واردة")
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setOngoing(true)
            .setTimeoutAfter(45_000)
            .setContentIntent(pi)
            .setFullScreenIntent(pi, true)
            .build()
        Notifs.post(this, Notifs.ID_CALL, n)
    }

    private fun notifyMsg(u: Unread) {
        val body = when (u.lastKind) {
            "image" -> "📷 صورة"
            "video" -> "🎬 فيديو"
            "file" -> "📎 " + (u.lastBody ?: "ملف")
            else -> u.lastBody ?: ""
        }
        val n = NotificationCompat.Builder(this, Notifs.CH_MSG)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(u.title + if (u.unread > 1) " (${u.unread})" else "")
            .setContentText(body)
            .setAutoCancel(true)
            .setContentIntent(Notifs.openApp(this, 20))
            .build()
        Notifs.post(this, u.convId.hashCode(), n)
    }

    private fun notifySos(s: Sos) {
        val n = NotificationCompat.Builder(this, Notifs.CH_SOS)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("🚨 SOS من " + s.displayName)
            .setContentText("يحتاج مساعدة! افتح التطبيق لمعرفة موقعه.")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(Notifs.openApp(this, 30))
            .setFullScreenIntent(Notifs.openApp(this, 31), true)
            .build()
        Notifs.post(this, Notifs.ID_SOS, n)
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
