package com.ajam.family

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner

class MainActivity : ComponentActivity() {
    private val vm: AppVm by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        Prefs.init(applicationContext)
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT))
        lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onStart(owner: LifecycleOwner) { vm.onForeground(true) }
            override fun onStop(owner: LifecycleOwner) { vm.onForeground(false) }
        })
        setContent {
            AjamTheme {
                // Arabic-first: always right-to-left.
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { AppRoot() }
                }
            }
        }
    }
}

@Composable
fun AjamTheme(content: @Composable () -> Unit) {
    val scheme = if (isSystemInDarkTheme()) {
        darkColorScheme(
            primary = Color(0xFF2EE6A8), onPrimary = Color(0xFF00382A),
            secondary = Color(0xFFFFD54A), background = Color(0xFF0B1412), surface = Color(0xFF111C19),
            surfaceVariant = Color(0xFF1D2D29), primaryContainer = Color(0xFF0F5E4B)
        )
    } else {
        lightColorScheme(
            primary = Color(0xFF0F8F6D), onPrimary = Color.White,
            secondary = Color(0xFFE0A800), background = Color(0xFFF4FAF8), surface = Color.White,
            surfaceVariant = Color(0xFFE6F1EE), primaryContainer = Color(0xFFCDEFE3)
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
