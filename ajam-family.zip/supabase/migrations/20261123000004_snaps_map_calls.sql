-- Phase 2-4: snaps, stories, score, streaks, map/SOS, calls, unread summary. RLS on every table; access via server functions.

-- ===== tables =====
create table public.snaps (
  id uuid primary key default gen_random_uuid(),
  family_id uuid not null references public.families(id),
  sender_id uuid not null references public.profiles(id),
  media_path text not null,
  kind text not null check (kind in ('photo','video')),
  view_seconds int check (view_seconds between 1 and 10),
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default now() + interval '30 days'
);
create table public.snap_recipients (
  snap_id uuid not null references public.snaps(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  view_count int not null default 0,
  first_viewed_at timestamptz,
  primary key (snap_id, user_id)
);
create table public.stories (
  id uuid primary key default gen_random_uuid(),
  family_id uuid not null references public.families(id),
  user_id uuid not null references public.profiles(id) on delete cascade,
  media_path text not null,
  kind text not null check (kind in ('photo','video')),
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default now() + interval '24 hours'
);
create table public.story_views (
  story_id uuid not null references public.stories(id) on delete cascade,
  viewer_id uuid not null references public.profiles(id) on delete cascade,
  viewed_at timestamptz not null default now(),
  primary key (story_id, viewer_id)
);
create table public.scores (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  points int not null default 0
);
create table public.streaks (
  user_a uuid not null, user_b uuid not null,
  count int not null default 0,
  last_a timestamptz, last_b timestamptz, last_count_at timestamptz,
  primary key (user_a, user_b), check (user_a < user_b)
);
create table public.sharing_settings (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  enabled boolean not null default false,
  precise boolean not null default true,
  ghost text not null default 'off' check (ghost in ('off','hide','freeze')),
  ghost_until timestamptz
);
create table public.hidden_from (
  user_id uuid not null references public.profiles(id) on delete cascade,
  hidden_user uuid not null references public.profiles(id) on delete cascade,
  primary key (user_id, hidden_user)
);
create table public.locations (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  lat double precision not null, lng double precision not null,
  accuracy real, speed real, battery int, charging boolean,
  updated_at timestamptz not null default now()
);
create table public.sos_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  family_id uuid not null references public.families(id),
  lat double precision, lng double precision,
  created_at timestamptz not null default now(),
  resolved_at timestamptz
);
create table public.calls (
  id uuid primary key default gen_random_uuid(),
  family_id uuid not null references public.families(id),
  caller_id uuid not null references public.profiles(id) on delete cascade,
  callee_id uuid not null references public.profiles(id) on delete cascade,
  kind text not null check (kind in ('audio','video')),
  status text not null default 'ringing' check (status in ('ringing','accepted','declined','ended','missed')),
  created_at timestamptz not null default now(),
  answered_at timestamptz, ended_at timestamptz
);
create table public.call_signals (
  id bigserial primary key,
  call_id uuid not null references public.calls(id) on delete cascade,
  from_id uuid not null, to_id uuid not null,
  kind text not null check (kind in ('offer','answer','ice')),
  payload jsonb not null,
  created_at timestamptz not null default now()
);
create index on public.call_signals (call_id, to_id, id);

alter table public.snaps enable row level security;
alter table public.snap_recipients enable row level security;
alter table public.stories enable row level security;
alter table public.story_views enable row level security;
alter table public.scores enable row level security;
alter table public.streaks enable row level security;
alter table public.sharing_settings enable row level security;
alter table public.hidden_from enable row level security;
alter table public.locations enable row level security;
alter table public.sos_events enable row level security;
alter table public.calls enable row level security;
alter table public.call_signals enable row level security;
-- No direct policies: clients can only use the server functions below (scores can never be written by a client).

-- ===== internal helpers (not callable by clients) =====
create function public.add_score(p_user uuid, p_n int) returns void
language sql security definer set search_path = public as $$
  insert into public.scores (user_id, points) values (p_user, p_n)
  on conflict (user_id) do update set points = public.scores.points + p_n
$$;

create function public.touch_streak(p_sender uuid, p_other uuid) returns void
language plpgsql security definer set search_path = public as $$
declare
  u1 uuid := least(p_sender, p_other);
  u2 uuid := greatest(p_sender, p_other);
  s public.streaks;
  both_sent boolean;
  bonus int;
begin
  insert into public.streaks (user_a, user_b) values (u1, u2) on conflict do nothing;
  select * into s from public.streaks where user_a = u1 and user_b = u2 for update;
  if s.last_count_at is not null and now() - s.last_count_at > interval '48 hours' then
    s.count := 0; s.last_count_at := null; s.last_a := null; s.last_b := null;
  end if;
  if p_sender = u1 then s.last_a := now(); else s.last_b := now(); end if;
  both_sent := s.last_a is not null and s.last_b is not null
    and (s.last_count_at is null or (s.last_a > s.last_count_at and s.last_b > s.last_count_at));
  if both_sent and (s.last_count_at is null or now() - s.last_count_at >= interval '20 hours') then
    s.count := s.count + 1;
    s.last_count_at := now();
    bonus := case s.count when 7 then 10 when 30 then 40 when 100 then 100 else 0 end;
    if bonus > 0 then
      perform public.add_score(u1, bonus);
      perform public.add_score(u2, bonus);
    end if;
  end if;
  update public.streaks set count = s.count, last_a = s.last_a, last_b = s.last_b, last_count_at = s.last_count_at
   where user_a = u1 and user_b = u2;
end $$;
revoke all on function public.add_score(uuid, int) from public, anon, authenticated;
revoke all on function public.touch_streak(uuid, uuid) from public, anon, authenticated;

-- ===== snaps =====
create function public.send_snap(p_path text, p_kind text, p_recipients uuid[], p_seconds int default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare fid uuid := public.my_family_id(); sid uuid; r uuid;
begin
  if fid is null then raise exception 'no_family'; end if;
  if p_path not like (auth.uid()::text || '/%') then raise exception 'bad_path'; end if;
  if coalesce(array_length(p_recipients, 1), 0) = 0 then raise exception 'no_recipients'; end if;
  if (select count(*) from public.snaps where sender_id = auth.uid() and created_at > now() - interval '1 minute') >= 20 then
    raise exception 'rate_limited';
  end if;
  insert into public.snaps (family_id, sender_id, media_path, kind, view_seconds)
    values (fid, auth.uid(), p_path, p_kind, p_seconds) returning id into sid;
  foreach r in array p_recipients loop
    if r <> auth.uid() and exists (select 1 from public.profiles where id = r and family_id = fid and status = 'active') then
      insert into public.snap_recipients (snap_id, user_id) values (sid, r) on conflict do nothing;
      perform public.touch_streak(auth.uid(), r);
    end if;
  end loop;
  perform public.add_score(auth.uid(), 1);
  return sid;
end $$;

create function public.get_inbox()
returns table (snap_id uuid, sender_id uuid, kind text, view_seconds int, view_count int, created_at timestamptz)
language sql stable security definer set search_path = public as $$
  select s.id, s.sender_id, s.kind, s.view_seconds, r.view_count, s.created_at
  from public.snap_recipients r join public.snaps s on s.id = r.snap_id
  where r.user_id = auth.uid() and r.view_count < 2 and s.expires_at > now()
  order by s.created_at desc
$$;

create function public.open_snap(p_snap uuid) returns text
language plpgsql security definer set search_path = public as $$
declare r public.snap_recipients; s public.snaps;
begin
  select * into r from public.snap_recipients where snap_id = p_snap and user_id = auth.uid() for update;
  if not found or r.view_count >= 2 then raise exception 'not_available'; end if;
  select * into s from public.snaps where id = p_snap and expires_at > now();
  if not found then raise exception 'not_available'; end if;
  update public.snap_recipients set view_count = view_count + 1, first_viewed_at = coalesce(first_viewed_at, now())
   where snap_id = p_snap and user_id = auth.uid();
  if r.view_count = 0 then perform public.add_score(auth.uid(), 1); end if;
  return s.media_path;
end $$;

-- ===== stories =====
create function public.post_story(p_path text, p_kind text) returns uuid
language plpgsql security definer set search_path = public as $$
declare fid uuid := public.my_family_id(); sid uuid;
begin
  if fid is null then raise exception 'no_family'; end if;
  if p_path not like (auth.uid()::text || '/%') then raise exception 'bad_path'; end if;
  insert into public.stories (family_id, user_id, media_path, kind) values (fid, auth.uid(), p_path, p_kind) returning id into sid;
  perform public.add_score(auth.uid(), 2);
  return sid;
end $$;

create function public.get_stories()
returns table (story_id uuid, user_id uuid, kind text, media_path text, created_at timestamptz, viewed boolean)
language sql stable security definer set search_path = public as $$
  select st.id, st.user_id, st.kind, st.media_path, st.created_at,
         exists (select 1 from public.story_views v where v.story_id = st.id and v.viewer_id = auth.uid())
  from public.stories st
  where st.family_id = public.my_family_id() and st.expires_at > now()
  order by st.created_at
$$;

create function public.view_story(p_story uuid) returns void
language sql security definer set search_path = public as $$
  insert into public.story_views (story_id, viewer_id)
  select st.id, auth.uid() from public.stories st
   where st.id = p_story and st.family_id = public.my_family_id() and st.user_id <> auth.uid()
  on conflict do nothing
$$;

create function public.get_story_viewers(p_story uuid)
returns table (viewer_id uuid, viewed_at timestamptz)
language sql stable security definer set search_path = public as $$
  select v.viewer_id, v.viewed_at from public.story_views v join public.stories st on st.id = v.story_id
  where v.story_id = p_story and st.user_id = auth.uid() order by v.viewed_at
$$;

-- ===== score / streaks =====
create function public.get_leaderboard()
returns table (user_id uuid, display_name text, points int)
language sql stable security definer set search_path = public as $$
  select p.id, p.display_name, coalesce(s.points, 0)
  from public.profiles p left join public.scores s on s.user_id = p.id
  where p.family_id = public.my_family_id() and p.status = 'active'
  order by coalesce(s.points, 0) desc, p.display_name
$$;

create function public.get_streaks()
returns table (other_id uuid, day_count int, alive boolean, warn boolean, i_sent boolean, they_sent boolean)
language sql stable security definer set search_path = public as $$
  select case when st.user_a = auth.uid() then st.user_b else st.user_a end,
         st.count,
         true,
         (st.last_count_at + interval '48 hours' - now()) < interval '4 hours',
         case when st.user_a = auth.uid()
              then coalesce(st.last_a > st.last_count_at, false)
              else coalesce(st.last_b > st.last_count_at, false) end,
         case when st.user_a = auth.uid()
              then coalesce(st.last_b > st.last_count_at, false)
              else coalesce(st.last_a > st.last_count_at, false) end
  from public.streaks st
  where (st.user_a = auth.uid() or st.user_b = auth.uid())
    and st.count > 0 and st.last_count_at is not null
    and now() - st.last_count_at <= interval '48 hours'
  order by st.count desc
$$;

-- ===== map / location =====
create function public.get_my_sharing()
returns table (enabled boolean, precise boolean, ghost text, ghost_until timestamptz)
language sql stable security definer set search_path = public as $$
  select s.enabled, s.precise, s.ghost, s.ghost_until from public.sharing_settings s where s.user_id = auth.uid()
$$;

create function public.set_sharing(p_enabled boolean, p_precise boolean) returns void
language sql security definer set search_path = public as $$
  insert into public.sharing_settings (user_id, enabled, precise) values (auth.uid(), p_enabled, p_precise)
  on conflict (user_id) do update set enabled = p_enabled, precise = p_precise
$$;

create function public.set_ghost(p_mode text, p_hours int default null) returns void
language plpgsql security definer set search_path = public as $$
begin
  if p_mode not in ('off','hide','freeze') then raise exception 'bad_mode'; end if;
  insert into public.sharing_settings (user_id, ghost, ghost_until)
    values (auth.uid(), p_mode, case when p_mode = 'off' or p_hours is null then null else now() + make_interval(hours => p_hours) end)
  on conflict (user_id) do update
    set ghost = excluded.ghost, ghost_until = excluded.ghost_until;
end $$;

create function public.set_hidden(p_user uuid, p_hidden boolean) returns void
language plpgsql security definer set search_path = public as $$
begin
  if p_hidden then
    insert into public.hidden_from (user_id, hidden_user) values (auth.uid(), p_user) on conflict do nothing;
  else
    delete from public.hidden_from where user_id = auth.uid() and hidden_user = p_user;
  end if;
end $$;

create function public.get_hidden() returns table (hidden_user uuid)
language sql stable security definer set search_path = public as $$
  select h.hidden_user from public.hidden_from h where h.user_id = auth.uid()
$$;

create function public.update_location(p_lat double precision, p_lng double precision, p_acc real,
                                        p_speed real, p_battery int, p_charging boolean) returns void
language plpgsql security definer set search_path = public as $$
declare st public.sharing_settings;
begin
  select * into st from public.sharing_settings where user_id = auth.uid();
  if not found or not st.enabled then return; end if;
  if st.ghost = 'freeze' and (st.ghost_until is null or st.ghost_until > now()) then return; end if;
  insert into public.locations (user_id, lat, lng, accuracy, speed, battery, charging, updated_at)
    values (auth.uid(), p_lat, p_lng, p_acc, p_speed, p_battery, p_charging, now())
  on conflict (user_id) do update set lat = excluded.lat, lng = excluded.lng, accuracy = excluded.accuracy,
    speed = excluded.speed, battery = excluded.battery, charging = excluded.charging, updated_at = now();
end $$;

create function public.get_family_locations()
returns table (user_id uuid, lat double precision, lng double precision, speed real, battery int, charging boolean, updated_at timestamptz)
language sql stable security definer set search_path = public as $$
  select l.user_id,
         case when l.user_id = auth.uid() or coalesce(st.precise, true) then l.lat else round(l.lat::numeric, 2)::double precision end,
         case when l.user_id = auth.uid() or coalesce(st.precise, true) then l.lng else round(l.lng::numeric, 2)::double precision end,
         l.speed, l.battery, l.charging, l.updated_at
  from public.locations l
  join public.profiles p on p.id = l.user_id
  left join public.sharing_settings st on st.user_id = l.user_id
  where p.family_id = public.my_family_id() and p.status = 'active'
    and (l.user_id = auth.uid() or (
      coalesce(st.enabled, false)
      and (st.ghost <> 'hide' or (st.ghost_until is not null and st.ghost_until <= now()))
      and not exists (select 1 from public.hidden_from h where h.user_id = l.user_id and h.hidden_user = auth.uid())))
$$;

-- ===== SOS =====
create function public.start_sos(p_lat double precision, p_lng double precision) returns uuid
language plpgsql security definer set search_path = public as $$
declare fid uuid := public.my_family_id(); sid uuid;
begin
  if fid is null then raise exception 'no_family'; end if;
  update public.sos_events set resolved_at = now() where user_id = auth.uid() and resolved_at is null;
  insert into public.sos_events (user_id, family_id, lat, lng) values (auth.uid(), fid, p_lat, p_lng) returning id into sid;
  return sid;
end $$;

create function public.update_sos(p_lat double precision, p_lng double precision) returns void
language sql security definer set search_path = public as $$
  update public.sos_events set lat = p_lat, lng = p_lng where user_id = auth.uid() and resolved_at is null
$$;

create function public.end_sos() returns void
language sql security definer set search_path = public as $$
  update public.sos_events set resolved_at = now() where user_id = auth.uid() and resolved_at is null
$$;

create function public.get_active_sos()
returns table (id uuid, user_id uuid, lat double precision, lng double precision, created_at timestamptz, display_name text)
language sql stable security definer set search_path = public as $$
  select e.id, e.user_id, e.lat, e.lng, e.created_at, p.display_name
  from public.sos_events e join public.profiles p on p.id = e.user_id
  where e.family_id = public.my_family_id() and e.resolved_at is null and e.created_at > now() - interval '12 hours'
$$;

-- ===== calls =====
create function public.start_call(p_callee uuid, p_kind text) returns uuid
language plpgsql security definer set search_path = public as $$
declare fid uuid := public.my_family_id(); cid uuid;
begin
  if fid is null then raise exception 'no_family'; end if;
  if not exists (select 1 from public.profiles where id = p_callee and family_id = fid and status = 'active') then
    raise exception 'not_in_family';
  end if;
  update public.calls set status = 'missed' where status = 'ringing' and created_at < now() - interval '45 seconds';
  if exists (select 1 from public.calls where (caller_id = p_callee or callee_id = p_callee)
             and status in ('ringing','accepted') and created_at > now() - interval '3 hours') then
    raise exception 'busy';
  end if;
  insert into public.calls (family_id, caller_id, callee_id, kind) values (fid, auth.uid(), p_callee, p_kind) returning id into cid;
  return cid;
end $$;

create function public.get_incoming_call() returns table (id uuid, caller_id uuid, kind text)
language plpgsql security definer set search_path = public as $$
begin
  update public.calls set status = 'missed' where status = 'ringing' and created_at < now() - interval '45 seconds';
  return query select c.id, c.caller_id, c.kind from public.calls c
    where c.callee_id = auth.uid() and c.status = 'ringing' order by c.created_at desc limit 1;
end $$;

create function public.answer_call(p_call uuid) returns void
language sql security definer set search_path = public as $$
  update public.calls set status = 'accepted', answered_at = now()
   where id = p_call and callee_id = auth.uid() and status = 'ringing'
$$;

create function public.decline_call(p_call uuid) returns void
language sql security definer set search_path = public as $$
  update public.calls set status = 'declined', ended_at = now()
   where id = p_call and callee_id = auth.uid() and status = 'ringing'
$$;

create function public.end_call(p_call uuid) returns void
language sql security definer set search_path = public as $$
  update public.calls
     set status = case when status = 'ringing' then 'missed' else 'ended' end, ended_at = now()
   where id = p_call and (caller_id = auth.uid() or callee_id = auth.uid()) and status in ('ringing','accepted')
$$;

create function public.call_status(p_call uuid) returns text
language sql stable security definer set search_path = public as $$
  select c.status from public.calls c where c.id = p_call and (c.caller_id = auth.uid() or c.callee_id = auth.uid())
$$;

create function public.send_signal(p_call uuid, p_to uuid, p_kind text, p_payload jsonb) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from public.calls c where c.id = p_call
       and ((c.caller_id = auth.uid() and c.callee_id = p_to) or (c.callee_id = auth.uid() and c.caller_id = p_to))) then
    raise exception 'not_in_call';
  end if;
  insert into public.call_signals (call_id, from_id, to_id, kind, payload) values (p_call, auth.uid(), p_to, p_kind, p_payload);
end $$;

create function public.get_signals(p_call uuid, p_after bigint)
returns table (id bigint, from_id uuid, kind text, payload jsonb)
language sql stable security definer set search_path = public as $$
  select s.id, s.from_id, s.kind, s.payload from public.call_signals s
  where s.call_id = p_call and s.to_id = auth.uid() and s.id > p_after order by s.id
$$;

create function public.get_call_history()
returns table (id uuid, other_id uuid, kind text, status text, outgoing boolean, created_at timestamptz)
language sql stable security definer set search_path = public as $$
  select c.id, case when c.caller_id = auth.uid() then c.callee_id else c.caller_id end,
         c.kind, c.status, c.caller_id = auth.uid(), c.created_at
  from public.calls c where c.caller_id = auth.uid() or c.callee_id = auth.uid()
  order by c.created_at desc limit 50
$$;

-- ===== unread summary (badges + notifications) =====
create function public.get_unread()
returns table (conv_id uuid, title text, unread int, last_msg_id uuid, last_body text, last_kind text, muted boolean)
language sql stable security definer set search_path = public as $$
  select cm.conversation_id,
         case when c.kind = 'group' then coalesce(c.name, 'مجموعة')
              else coalesce((select p.display_name from public.conversation_members m2
                             join public.profiles p on p.id = m2.user_id
                             where m2.conversation_id = c.id and m2.user_id <> auth.uid() limit 1), 'محادثة') end,
         count(m.id)::int,
         (array_agg(m.id order by m.created_at desc))[1],
         (array_agg(m.body order by m.created_at desc))[1],
         (array_agg(m.kind order by m.created_at desc))[1],
         cm.muted
  from public.conversation_members cm
  join public.conversations c on c.id = cm.conversation_id and c.family_id = public.my_family_id()
  join public.messages m on m.conversation_id = c.id and m.sender_id <> auth.uid()
       and m.created_at > cm.last_read_at and m.deleted_at is null
  where cm.user_id = auth.uid()
  group by cm.conversation_id, c.id, c.kind, c.name, cm.muted
$$;

-- ===== storage bucket for snaps/stories =====
insert into storage.buckets (id, name, public) values ('snaps', 'snaps', false) on conflict (id) do nothing;

create policy snaps_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'snaps' and (storage.foldername(name))[1] = auth.uid()::text);
create policy snaps_select on storage.objects for select to authenticated
  using (bucket_id = 'snaps' and (
    (storage.foldername(name))[1] = auth.uid()::text
    or exists (select 1 from public.snap_recipients r join public.snaps s on s.id = r.snap_id
               where s.media_path = name and r.user_id = auth.uid() and r.view_count between 1 and 2)
    or exists (select 1 from public.stories st
               where st.media_path = name and st.family_id = public.my_family_id() and st.expires_at > now())));

-- ===== grants =====
grant execute on function
  public.send_snap(text, text, uuid[], int), public.get_inbox(), public.open_snap(uuid),
  public.post_story(text, text), public.get_stories(), public.view_story(uuid), public.get_story_viewers(uuid),
  public.get_leaderboard(), public.get_streaks(),
  public.get_my_sharing(), public.set_sharing(boolean, boolean), public.set_ghost(text, int),
  public.set_hidden(uuid, boolean), public.get_hidden(),
  public.update_location(double precision, double precision, real, real, int, boolean),
  public.get_family_locations(),
  public.start_sos(double precision, double precision), public.update_sos(double precision, double precision),
  public.end_sos(), public.get_active_sos(),
  public.start_call(uuid, text), public.get_incoming_call(), public.answer_call(uuid), public.decline_call(uuid),
  public.end_call(uuid), public.call_status(uuid), public.send_signal(uuid, uuid, text, jsonb),
  public.get_signals(uuid, bigint), public.get_call_history(), public.get_unread()
to authenticated;

-- ===== cleanup job (optional: only if pg_cron is available) =====
do $$
begin
  create extension if not exists pg_cron;
  perform cron.schedule('ajam-cleanup', '*/30 * * * *', $c$
    delete from public.snaps s where s.expires_at < now()
      or not exists (select 1 from public.snap_recipients r where r.snap_id = s.id and r.view_count < 2)
      or not exists (select 1 from public.snap_recipients r where r.snap_id = s.id
                     and (r.first_viewed_at is null or r.first_viewed_at > now() - interval '1 hour'));
    delete from public.stories where expires_at < now();
    delete from public.call_signals where created_at < now() - interval '1 day';
  $c$);
exception when others then
  raise notice 'pg_cron not available: %', sqlerrm;
end $$;
