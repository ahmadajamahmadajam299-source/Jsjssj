package com.ajam.family

import android.content.Context
import android.media.AudioManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import org.webrtc.AudioTrack
import org.webrtc.Camera2Enumerator
import org.webrtc.CameraVideoCapturer
import org.webrtc.DefaultVideoDecoderFactory
import org.webrtc.DefaultVideoEncoderFactory
import org.webrtc.EglBase
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.RtpReceiver
import org.webrtc.RtpTransceiver
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import org.webrtc.SurfaceTextureHelper
import org.webrtc.VideoTrack
import org.webrtc.DataChannel

private open class SimpleSdp : SdpObserver {
    override fun onCreateSuccess(sdp: SessionDescription?) {}
    override fun onSetSuccess() {}
    override fun onCreateFailure(error: String?) {}
    override fun onSetFailure(error: String?) {}
}

/**
 * One-to-one WebRTC call. Signaling goes through the Supabase `call_signals` table (polled every ~0.8s).
 * Uses Google's public STUN; TURN is optional (Prefs).
 */
class CallSession(
    private val app: Context,
    val callId: String,
    val peerId: String,
    val video: Boolean,
    private val isCaller: Boolean,
    private val scope: CoroutineScope,
    private val onFinished: () -> Unit
) {
    var state by mutableStateOf(if (isCaller) "يرن..." else "جارٍ الاتصال...")
    var remoteVideo by mutableStateOf<VideoTrack?>(null)
    var localVideo by mutableStateOf<VideoTrack?>(null)
    var muted by mutableStateOf(false)
    var camOff by mutableStateOf(false)
    var speaker by mutableStateOf(video)
    var connected by mutableStateOf(false)

    val egl: EglBase = EglBase.create()
    @Volatile private var ended = false
    private var factory: PeerConnectionFactory? = null
    private var pc: PeerConnection? = null
    private var audioTrack: AudioTrack? = null
    private var vTrack: VideoTrack? = null
    private var capturer: CameraVideoCapturer? = null
    private var helper: SurfaceTextureHelper? = null
    private var remoteSet = false
    private val pendingIce = ArrayList<IceCandidate>()
    private val audioManager = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    companion object {
        private var inited = false
        fun initOnce(ctx: Context) {
            if (inited) return
            PeerConnectionFactory.initialize(
                PeerConnectionFactory.InitializationOptions.builder(ctx.applicationContext).createInitializationOptions()
            )
            inited = true
        }
    }

    fun start() {
        initOnce(app)
        audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
        audioManager.isSpeakerphoneOn = speaker
        val f = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(egl.eglBaseContext, true, true))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(egl.eglBaseContext))
            .createPeerConnectionFactory()
        factory = f

        val servers = ArrayList<PeerConnection.IceServer>()
        servers.add(PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer())
        servers.add(PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer())
        val turn = Prefs.turnUrl
        if (turn.isNotBlank()) {
            servers.add(
                PeerConnection.IceServer.builder(turn)
                    .setUsername(Prefs.turnUser).setPassword(Prefs.turnPass).createIceServer()
            )
        }
        val cfg = PeerConnection.RTCConfiguration(servers).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
        }

        val peer = f.createPeerConnection(cfg, object : PeerConnection.Observer {
            override fun onSignalingChange(s: PeerConnection.SignalingState?) {}
            override fun onIceConnectionChange(s: PeerConnection.IceConnectionState?) {
                when (s) {
                    PeerConnection.IceConnectionState.CONNECTED, PeerConnection.IceConnectionState.COMPLETED -> {
                        connected = true; state = "متصل"
                    }
                    PeerConnection.IceConnectionState.FAILED ->
                        state = "فشل الاتصال (قد تحتاج خادم TURN على هذه الشبكة)"
                    PeerConnection.IceConnectionState.DISCONNECTED -> state = "انقطع الاتصال..."
                    else -> {}
                }
            }
            override fun onIceConnectionReceivingChange(b: Boolean) {}
            override fun onIceGatheringChange(s: PeerConnection.IceGatheringState?) {}
            override fun onIceCandidate(c: IceCandidate) {
                scope.launch {
                    try {
                        Api.sendSignal(callId, peerId, "ice", buildJsonObject {
                            put("sdpMid", c.sdpMid ?: "")
                            put("sdpMLineIndex", c.sdpMLineIndex)
                            put("candidate", c.sdp)
                        })
                    } catch (e: CancellationException) { throw e } catch (e: Exception) { }
                }
            }
            override fun onIceCandidatesRemoved(c: Array<out IceCandidate>?) {}
            override fun onAddStream(s: MediaStream?) {}
            override fun onRemoveStream(s: MediaStream?) {}
            override fun onDataChannel(d: DataChannel?) {}
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(r: RtpReceiver?, s: Array<out MediaStream>?) {}
            override fun onTrack(t: RtpTransceiver?) {
                val track = t?.receiver?.track()
                if (track is VideoTrack) remoteVideo = track
            }
        })
        pc = peer
        if (peer == null) { finish("تعذر بدء المكالمة"); return }

        val audioSource = f.createAudioSource(MediaConstraints())
        val at = f.createAudioTrack("a0", audioSource)
        audioTrack = at
        peer.addTrack(at, listOf("stream"))

        if (video) {
            val cap = createCapturer(true)
            if (cap != null) {
                capturer = cap
                val h = SurfaceTextureHelper.create("capture", egl.eglBaseContext)
                helper = h
                val src = f.createVideoSource(cap.isScreencast)
                cap.initialize(h, app, src.capturerObserver)
                cap.startCapture(640, 480, 24)
                val vt = f.createVideoTrack("v0", src)
                vTrack = vt
                localVideo = vt
                peer.addTrack(vt, listOf("stream"))
            }
        }

        if (isCaller) {
            val mc = MediaConstraints().apply {
                mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"))
                mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", video.toString()))
            }
            peer.createOffer(object : SimpleSdp() {
                override fun onCreateSuccess(sdp: SessionDescription?) {
                    if (sdp == null) return
                    peer.setLocalDescription(SimpleSdp(), sdp)
                    scope.launch {
                        try {
                            Api.sendSignal(callId, peerId, "offer", buildJsonObject { put("sdp", sdp.description) })
                        } catch (e: CancellationException) { throw e } catch (e: Exception) { }
                    }
                }
            }, mc)
        }
        scope.launch { loop() }
    }

    private fun createCapturer(front: Boolean): CameraVideoCapturer? {
        val e = Camera2Enumerator(app)
        for (n in e.deviceNames) {
            if (e.isFrontFacing(n) == front) e.createCapturer(n, null)?.let { return it }
        }
        for (n in e.deviceNames) e.createCapturer(n, null)?.let { return it }
        return null
    }

    private fun flushIce() {
        val p = pc ?: return
        for (c in pendingIce) p.addIceCandidate(c)
        pendingIce.clear()
    }

    private fun handleOffer(sdp: String) {
        val p = pc ?: return
        p.setRemoteDescription(object : SimpleSdp() {
            override fun onSetSuccess() {
                remoteSet = true
                flushIce()
                val mc = MediaConstraints().apply {
                    mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"))
                    mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", video.toString()))
                }
                p.createAnswer(object : SimpleSdp() {
                    override fun onCreateSuccess(answer: SessionDescription?) {
                        if (answer == null) return
                        p.setLocalDescription(SimpleSdp(), answer)
                        scope.launch {
                            try {
                                Api.sendSignal(callId, peerId, "answer", buildJsonObject { put("sdp", answer.description) })
                            } catch (e: CancellationException) { throw e } catch (e: Exception) { }
                        }
                    }
                }, mc)
            }
        }, SessionDescription(SessionDescription.Type.OFFER, sdp))
    }

    private fun handleAnswer(sdp: String) {
        val p = pc ?: return
        p.setRemoteDescription(object : SimpleSdp() {
            override fun onSetSuccess() { remoteSet = true; flushIce() }
        }, SessionDescription(SessionDescription.Type.ANSWER, sdp))
    }

    private fun handleIce(o: JsonObject) {
        val cand = IceCandidate(
            o["sdpMid"]?.jsonPrimitive?.contentOrNull ?: "",
            o["sdpMLineIndex"]?.jsonPrimitive?.intOrNull ?: 0,
            o["candidate"]?.jsonPrimitive?.contentOrNull ?: return
        )
        if (remoteSet) pc?.addIceCandidate(cand) else pendingIce.add(cand)
    }

    private suspend fun loop() {
        var after = 0L
        while (!ended) {
            try {
                for (s in Api.signals(callId, after)) {
                    if (s.id > after) after = s.id
                    when (s.kind) {
                        "offer" -> s.payload["sdp"]?.jsonPrimitive?.contentOrNull?.let { handleOffer(it) }
                        "answer" -> s.payload["sdp"]?.jsonPrimitive?.contentOrNull?.let { handleAnswer(it) }
                        "ice" -> handleIce(s.payload)
                    }
                }
                val st = Api.callStatus(callId)
                if (st == "accepted" && !connected && isCaller) state = "جارٍ الاتصال..."
                if (st == "ended" || st == "declined" || st == "missed") {
                    finish(if (st == "declined") "تم رفض المكالمة" else if (st == "missed") "لم يتم الرد" else "انتهت المكالمة")
                    return
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) { }
            delay(800)
        }
    }

    fun toggleMute() { muted = !muted; audioTrack?.setEnabled(!muted) }
    fun toggleCam() { camOff = !camOff; vTrack?.setEnabled(!camOff) }
    fun toggleSpeaker() { speaker = !speaker; audioManager.isSpeakerphoneOn = speaker }
    fun flipCamera() { capturer?.switchCamera(null) }

    fun hangup() {
        scope.launch { try { Api.endCall(callId) } catch (e: Exception) { } }
        finish("انتهت المكالمة")
    }

    @Synchronized
    private fun finish(msg: String) {
        if (ended) return
        ended = true
        state = msg
        try { capturer?.stopCapture() } catch (e: Exception) { }
        try { capturer?.dispose() } catch (e: Exception) { }
        try { helper?.dispose() } catch (e: Exception) { }
        try { pc?.close() } catch (e: Exception) { }
        try { pc?.dispose() } catch (e: Exception) { }
        try { factory?.dispose() } catch (e: Exception) { }
        try { audioManager.mode = AudioManager.MODE_NORMAL; audioManager.isSpeakerphoneOn = false } catch (e: Exception) { }
        scope.launch {
            delay(1200)
            onFinished()
            delay(600)
            try { egl.release() } catch (e: Exception) { }
        }
    }
}
