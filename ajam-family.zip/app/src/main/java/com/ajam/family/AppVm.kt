package com.ajam.family

import android.content.ContentResolver
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch

enum class Stage { Loading, Welcome, Username, Tour, FamilyGate, Pending, Main }

data class ConvItem(val id: String, val title: String, val isGroup: Boolean, val otherId: String?)

fun friendly(e: Throwable): String {
    val m = e.message ?: ""
    return when {
        "username_taken" in m -> "اسم المستخدم محجوز، اختر اسماً آخر"
        "invalid_code" in m -> "كود العائلة غير صحيح"
        "rate_limited" in m -> "رسائل كثيرة بسرعة، انتظر قليلاً"
        "already_in_family" in m -> "أنت منضم لعائلة بالفعل"
        "UnknownHost" in m || "Unable to resolve" in m || "timeout" in m.lowercase() ->
            "تعذّر الاتصال بالإنترنت"
        else -> "حدث خطأ: " + m.take(160)
    }
}

class AppVm : ViewModel() {
    var stage by mutableStateOf(Stage.Loading); private set
    var busy by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null)
    var me by mutableStateOf<Profile?>(null); private set
    var members by mutableStateOf<List<Profile>>(emptyList()); private set
    var convs by mutableStateOf<List<ConvItem>>(emptyList()); private set
    var joinCode by mutableStateOf<String?>(null); private set
    var usernameOk by mutableStateOf<Boolean?>(null); private set
    var openChat by mutableStateOf<ConvItem?>(null); private set
    var messages by mutableStateOf<List<Message>>(emptyList()); private set
    var receipts by mutableStateOf<Map<String, Pair<Boolean, Boolean>>>(emptyMap()); private set
    var unread by mutableStateOf<Map<String, Int>>(emptyMap()); private set
    var groupMemberIds by mutableStateOf<Map<String, List<String>>>(emptyMap()); private set

    @Volatile private var foreground = true

    /** Cache of signed storage URLs, keyed "bucket:path". */
    val urls = mutableStateMapOf<String, String>()
    fun ensureUrl(bucket: String, path: String) {
        val k = "$bucket:$path"
        if (urls.containsKey(k)) return
        launchQuiet { urls[k] = Repo.signedUrl(bucket, path) }
    }

    init {
        viewModelScope.launch {
            try {
                Repo.awaitInit()
                if (!Repo.hasSession()) stage = Stage.Welcome else refreshInternal()
            } catch (e: Throwable) {
                if (e is CancellationException) throw e
                error = friendly(e)
                stage = Stage.Welcome
            }
        }
        // Presence heartbeat: "online" = last_seen_at within the last ~50 seconds.
        viewModelScope.launch {
            while (true) {
                delay(20_000)
                if (foreground && stage == Stage.Main) touchNow()
            }
        }
    }

    fun onForeground(f: Boolean) {
        foreground = f
        if (stage == Stage.Main) launchQuiet { touchNow() }
    }

    private suspend fun touchNow() {
        try {
            me?.id?.let { Repo.touch(it) }
        } catch (e: Throwable) {
            if (e is CancellationException) throw e
        }
    }

    private fun launchSafe(block: suspend () -> Unit) = viewModelScope.launch {
        busy = true
        try {
            block()
        } catch (e: Throwable) {
            if (e is CancellationException) throw e
            error = friendly(e)
        } finally {
            busy = false
        }
    }

    private fun launchQuiet(block: suspend () -> Unit) = viewModelScope.launch {
        try { block() } catch (e: Throwable) { if (e is CancellationException) throw e }
    }

    private suspend fun refreshInternal() {
        val p = Repo.myProfile()
        me = p
        stage = when {
            p == null -> Stage.Welcome
            p.username == null -> Stage.Username
            !Prefs.tourDone -> Stage.Tour
            p.status == "none" -> Stage.FamilyGate
            p.status == "pending" -> Stage.Pending
            else -> { loadMain(); touchNow(); Stage.Main }
        }
    }

    private suspend fun loadMain() {
        members = Repo.members()
        val cs = Repo.conversations()
        val ms = Repo.convMembers()
        val byId = members.associateBy { it.id }
        val myId = me?.id
        convs = cs.map { c ->
            if (c.kind == "group") {
                ConvItem(c.id, c.name ?: "مجموعة", true, null)
            } else {
                val other = ms.firstOrNull { it.conversationId == c.id && it.userId != myId }
                ConvItem(c.id, byId[other?.userId]?.displayName ?: "محادثة", false, other?.userId)
            }
        }
        groupMemberIds = cs.filter { it.kind == "group" }.associate { c ->
            c.id to ms.filter { it.conversationId == c.id && it.userId != myId }.map { it.userId }
        }
        unread = try { Api.unread().associate { it.convId to it.unread } } catch (e: Exception) { unread }
        if (me?.role == "admin") joinCode = try { Repo.joinCode() } catch (e: Exception) { joinCode }
    }

    fun nameOf(id: String): String = members.firstOrNull { it.id == id }?.displayName ?: ""
    fun profileOf(id: String?): Profile? = members.firstOrNull { it.id == id }

    fun silentRefresh() { launchQuiet { refreshInternal() } }
    fun silentReload() {
        if (!foreground) return
        launchQuiet {
            me = Repo.myProfile()
            loadMain()
            try { Repo.markDelivered() } catch (e: Throwable) { if (e is CancellationException) throw e }
        }
    }

    fun finishTour() { Prefs.tourDone = true; silentRefresh() }

    fun submitName(name: String) = launchSafe {
        Repo.ensureSession()
        Repo.createProfile(name.trim())
        refreshInternal()
    }

    fun resetUsernameCheck() { usernameOk = null }
    fun checkUsername(u: String) { launchQuiet { usernameOk = Repo.usernameAvailable(u) } }
    fun claimUsername(u: String) = launchSafe { Repo.claimUsername(u); refreshInternal() }

    fun createFamily(name: String) = launchSafe { Repo.createFamily(name.trim()); refreshInternal() }
    fun joinFamily(code: String) = launchSafe { Repo.joinFamily(code); refreshInternal() }

    fun approve(id: String) = launchSafe { Repo.approve(id); loadMain() }
    fun promote(id: String) = launchSafe { Repo.promote(id); loadMain() }
    fun remove(id: String) = launchSafe { Repo.remove(id); loadMain() }
    fun newCode() = launchSafe { joinCode = Repo.newJoinCode() }

    fun startDirect(userId: String) = launchSafe {
        val id = Repo.direct(userId)
        loadMain()
        messages = emptyList(); receipts = emptyMap()
        openChat = convs.firstOrNull { it.id == id }
    }

    fun createGroup(name: String, ids: List<String>) = launchSafe {
        val id = Repo.createGroup(name.trim(), ids)
        loadMain()
        messages = emptyList(); receipts = emptyMap()
        openChat = convs.firstOrNull { it.id == id }
    }

    fun open(c: ConvItem) { messages = emptyList(); receipts = emptyMap(); openChat = c }
    fun closeChat() { openChat = null }

    private suspend fun loadChat(convId: String) {
        try { Repo.markRead(convId) } catch (e: Throwable) { if (e is CancellationException) throw e }
        messages = Repo.messages(convId)
        receipts = Repo.receipts(convId).associate { it.msgId to (it.delivered to it.read) }
    }

    fun pollMessages() {
        val c = openChat ?: return
        if (!foreground) return
        launchQuiet { loadChat(c.id) }
    }

    fun send(text: String) {
        val c = openChat ?: return
        val myId = me?.id ?: return
        val t = text.trim()
        if (t.isEmpty()) return
        viewModelScope.launch {
            try {
                Repo.send(c.id, myId, t)
                loadChat(c.id)
            } catch (e: Throwable) {
                if (e is CancellationException) throw e
                error = friendly(e)
            }
        }
    }

    fun uploadAvatar(cr: ContentResolver, uri: Uri) = launchSafe {
        val id = me?.id ?: return@launchSafe
        val bytes = withContext(Dispatchers.IO) { Media.compressImage(cr, uri, 512, true) }
        val path = "$id/${System.currentTimeMillis()}.jpg"
        Repo.upload("avatars", path, bytes)
        Repo.setAvatar(id, path)
        me = Repo.myProfile()
        loadMain()
    }

    fun sendMedia(cr: ContentResolver, uri: Uri) {
        val c = openChat ?: return
        val myId = me?.id ?: return
        launchSafe {
            val mime = cr.getType(uri) ?: "application/octet-stream"
            val name = Media.name(cr, uri)
            val kind = when {
                mime.startsWith("image/") -> "image"
                mime.startsWith("video/") -> "video"
                else -> "file"
            }
            val bytes: ByteArray? = withContext(Dispatchers.IO) {
                if (kind == "image") {
                    Media.compressImage(cr, uri, 1600, false)
                } else {
                    val sz = Media.size(cr, uri)
                    if (sz > Media.MAX_BYTES) null
                    else Media.readBytes(cr, uri).takeIf { it.size <= Media.MAX_BYTES }
                }
            }
            if (bytes == null) {
                error = "الملف كبير جداً، الحد الأقصى 25 ميغابايت"
                return@launchSafe
            }
            val ext = if (kind == "image") "jpg"
            else name.substringAfterLast('.', "bin").filter { it.isLetterOrDigit() }.take(8).ifEmpty { "bin" }
            val path = "${c.id}/${java.util.UUID.randomUUID()}.$ext"
            Repo.upload("chat-media", path, bytes)
            Repo.sendMessage(c.id, myId, if (kind == "image") null else name, kind, path)
            loadChat(c.id)
        }
    }

    fun saveProfile(name: String, bio: String) = launchSafe {
        val id = me?.id ?: return@launchSafe
        Repo.updateProfile(id, name.trim(), bio.trim())
        me = Repo.myProfile()
    }

    fun setHideLastSeen(v: Boolean) = launchQuiet {
        val id = me?.id ?: return@launchQuiet
        Repo.setHide(id, v)
        me = Repo.myProfile()
    }
}
