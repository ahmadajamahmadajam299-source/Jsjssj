package com.ajam.family

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay
import java.time.OffsetDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

@Composable
fun AppRoot(vm: AppVm = viewModel()) {
    Box(Modifier.fillMaxSize()) {
        when (vm.stage) {
            Stage.Loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
            Stage.Welcome -> WelcomeScreen(vm)
            Stage.Username -> UsernameScreen(vm)
            Stage.FamilyGate -> FamilyGateScreen(vm)
            Stage.Pending -> PendingScreen(vm)
            Stage.Main -> if (vm.openChat != null) ChatScreen(vm) else MainScreen(vm)
        }
        if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
    }
    vm.error?.let { msg ->
        AlertDialog(
            onDismissRequest = { vm.error = null },
            confirmButton = { TextButton(onClick = { vm.error = null }) { Text("حسناً") } },
            title = { Text("تنبيه") },
            text = { Text(msg) }
        )
    }
}

@Composable
fun Logo() {
    Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary, modifier = Modifier.size(88.dp)) {
        Box(contentAlignment = Alignment.Center) {
            Text("ع", fontSize = 44.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary)
        }
    }
}

@Composable
fun WelcomeScreen(vm: AppVm) {
    var name by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().padding(24.dp).imePadding(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Logo()
        Spacer(Modifier.height(16.dp))
        Text("عائلة العجم", style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(32.dp))
        OutlinedTextField(
            value = name, onValueChange = { name = it.take(40) },
            label = { Text("اكتب اسمك") }, singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { vm.submitName(name) },
            enabled = name.trim().isNotEmpty() && !vm.busy,
            modifier = Modifier.fillMaxWidth()
        ) { Text("متابعة") }
    }
}

@Composable
fun UsernameScreen(vm: AppVm) {
    var u by remember { mutableStateOf("") }
    LaunchedEffect(u) {
        vm.resetUsernameCheck()
        if (u.length >= 3) {
            delay(400)
            vm.checkUsername(u)
        }
    }
    Column(
        Modifier.fillMaxSize().padding(24.dp).imePadding(),
        verticalArrangement = Arrangement.Center
    ) {
        Text("اختر اسم المستخدم", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        Text("أحرف إنجليزية صغيرة وأرقام و _ و . فقط، ٣ أحرف على الأقل. الاسم دائم ولا يمكن تغييره أبداً.")
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = u,
            onValueChange = { s ->
                u = s.lowercase().filter { c -> c in 'a'..'z' || c in '0'..'9' || c == '_' || c == '.' }.take(24)
            },
            label = { Text("اسم المستخدم") }, singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        val status = when {
            u.isEmpty() -> ""
            u.length < 3 -> "٣ أحرف على الأقل"
            vm.usernameOk == true -> "متاح ✓"
            vm.usernameOk == false -> "محجوز، اختر غيره"
            else -> "جارٍ التحقق..."
        }
        Text(status)
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { vm.claimUsername(u) },
            enabled = vm.usernameOk == true && !vm.busy,
            modifier = Modifier.fillMaxWidth()
        ) { Text("تأكيد الاسم") }
    }
}

@Composable
fun FamilyGateScreen(vm: AppVm) {
    var mode by remember { mutableStateOf(0) }
    var text by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(24.dp).imePadding(), verticalArrangement = Arrangement.Center) {
        Text("العائلة", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (mode == 0) Button(onClick = { mode = 0; text = "" }) { Text("إنشاء عائلة") }
            else OutlinedButton(onClick = { mode = 0; text = "" }) { Text("إنشاء عائلة") }
            if (mode == 1) Button(onClick = { mode = 1; text = "" }) { Text("الانضمام بكود") }
            else OutlinedButton(onClick = { mode = 1; text = "" }) { Text("الانضمام بكود") }
        }
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = text,
            onValueChange = { text = if (mode == 1) it.uppercase().take(8) else it.take(60) },
            label = { Text(if (mode == 0) "اسم العائلة" else "كود العائلة") },
            singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { if (mode == 0) vm.createFamily(text) else vm.joinFamily(text) },
            enabled = text.trim().isNotEmpty() && !vm.busy,
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (mode == 0) "إنشاء" else "انضمام") }
        Spacer(Modifier.height(12.dp))
        Text("أول من ينشئ العائلة يصبح المدير.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun PendingScreen(vm: AppVm) {
    LaunchedEffect(Unit) {
        while (true) {
            delay(4000)
            vm.silentRefresh()
        }
    }
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        CircularProgressIndicator()
        Spacer(Modifier.height(24.dp))
        Text("بانتظار موافقة مدير العائلة...", style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text("سيفتح التطبيق تلقائياً بعد القبول.", textAlign = TextAlign.Center)
    }
}

@Composable
fun MainScreen(vm: AppVm) {
    var tab by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(5000)
            vm.silentReload()
        }
    }
    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            NavigationBar(windowInsets = WindowInsets(0, 0, 0, 0)) {
                NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Filled.Chat, null) }, label = { Text("المحادثات") })
                NavigationBarItem(tab == 1, { tab = 1 }, { Icon(Icons.Filled.Group, null) }, label = { Text("العائلة") })
                NavigationBarItem(tab == 2, { tab = 2 }, { Icon(Icons.Filled.Person, null) }, label = { Text("حسابي") })
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> ChatsTab(vm)
                1 -> FamilyTab(vm)
                else -> ProfileTab(vm)
            }
        }
    }
}

@Composable
fun Avatar(name: String, size: Int = 44) {
    Box(
        Modifier.size(size.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary),
        contentAlignment = Alignment.Center
    ) {
        Text(
            name.trim().take(1), color = MaterialTheme.colorScheme.onPrimary,
            fontWeight = FontWeight.Bold, fontSize = (size / 2.2).sp
        )
    }
}

@Composable
fun ChatsTab(vm: AppVm) {
    var showGroup by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize()) {
        if (vm.convs.isEmpty()) {
            Column(
                Modifier.fillMaxSize().padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("لا توجد محادثات بعد", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Text("افتح تبويب «العائلة» واضغط على أي فرد لبدء محادثة.", textAlign = TextAlign.Center)
            }
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(vm.convs, key = { it.id }) { c ->
                    Row(
                        Modifier.fillMaxWidth().clickable { vm.open(c) }.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Avatar(c.title)
                        Spacer(Modifier.size(12.dp))
                        Column {
                            Text(c.title, style = MaterialTheme.typography.titleMedium)
                            if (c.isGroup) Text("مجموعة", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    HorizontalDivider()
                }
            }
        }
        FloatingActionButton(
            onClick = { showGroup = true },
            modifier = Modifier.align(Alignment.BottomStart).padding(16.dp)
        ) { Icon(Icons.Filled.Add, "مجموعة جديدة") }
    }
    if (showGroup) NewGroupDialog(vm) { showGroup = false }
}

@Composable
fun NewGroupDialog(vm: AppVm, onClose: () -> Unit) {
    var name by remember { mutableStateOf("") }
    val picked = remember { mutableStateListOf<String>() }
    val others = vm.members.filter { it.id != vm.me?.id && it.status == "active" }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("مجموعة جديدة") },
        text = {
            Column {
                OutlinedTextField(name, { name = it.take(60) }, label = { Text("اسم المجموعة") }, singleLine = true)
                Spacer(Modifier.height(8.dp))
                LazyColumn(Modifier.height(240.dp)) {
                    items(others, key = { it.id }) { p ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(p.id in picked, { on -> if (on) picked.add(p.id) else picked.remove(p.id) })
                            Text(p.displayName)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.trim().isNotEmpty() && picked.isNotEmpty(),
                onClick = { vm.createGroup(name, picked.toList()); onClose() }
            ) { Text("إنشاء") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("إلغاء") } }
    )
}

@Composable
fun FamilyTab(vm: AppVm) {
    val ctx = LocalContext.current
    val isAdmin = vm.me?.role == "admin"
    val pending = vm.members.filter { it.status == "pending" }
    val active = vm.members.filter { it.status == "active" }
    LazyColumn(Modifier.fillMaxSize()) {
        if (isAdmin) {
            item {
                Card(Modifier.fillMaxWidth().padding(16.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("كود العائلة", style = MaterialTheme.typography.titleSmall)
                        Text(vm.joinCode ?: "...", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = {
                                val i = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, "انضم لعائلتنا في تطبيق عائلة العجم بالكود: ${vm.joinCode}")
                                }
                                ctx.startActivity(Intent.createChooser(i, "مشاركة الكود"))
                            }) { Text("مشاركة") }
                            OutlinedButton(onClick = { vm.newCode() }) { Text("كود جديد") }
                        }
                    }
                }
            }
            if (pending.isNotEmpty()) {
                item { Text("طلبات الانضمام", Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.titleSmall) }
                items(pending, key = { "p" + it.id }) { p ->
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Avatar(p.displayName)
                        Spacer(Modifier.size(12.dp))
                        Text(p.displayName, Modifier.weight(1f))
                        Button(onClick = { vm.approve(p.id) }) { Text("قبول") }
                        TextButton(onClick = { vm.remove(p.id) }) { Text("رفض") }
                    }
                }
            }
        }
        item { Text("أفراد العائلة", Modifier.padding(16.dp), style = MaterialTheme.typography.titleSmall) }
        items(active, key = { "a" + it.id }) { p ->
            val mine = p.id == vm.me?.id
            Row(
                Modifier.fillMaxWidth().clickable(enabled = !mine) { vm.startDirect(p.id) }.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Avatar(p.displayName)
                Spacer(Modifier.size(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(p.displayName + if (mine) " (أنت)" else "", style = MaterialTheme.typography.titleMedium)
                    Text("@" + (p.username ?: "") + if (p.role == "admin") " · مدير" else "", style = MaterialTheme.typography.bodySmall)
                }
                if (isAdmin && !mine) {
                    if (p.role != "admin") TextButton(onClick = { vm.promote(p.id) }) { Text("ترقية") }
                    TextButton(onClick = { vm.remove(p.id) }) { Text("إزالة") }
                }
            }
            HorizontalDivider()
        }
    }
}

@Composable
fun ProfileTab(vm: AppVm) {
    val me = vm.me
    var name by remember(me?.displayName) { mutableStateOf(me?.displayName ?: "") }
    var bio by remember(me?.bio) { mutableStateOf(me?.bio ?: "") }
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Avatar(name.ifBlank { "؟" }, 88)
        Spacer(Modifier.height(8.dp))
        Text("@" + (me?.username ?: ""), style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(name, { name = it.take(40) }, label = { Text("الاسم") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(bio, { bio = it.take(120) }, label = { Text("الحالة") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { vm.saveProfile(name, bio) },
            enabled = name.trim().isNotEmpty() && !vm.busy,
            modifier = Modifier.fillMaxWidth()
        ) { Text("حفظ") }
    }
}

private fun timeOf(iso: String): String = try {
    OffsetDateTime.parse(iso).atZoneSameInstant(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("HH:mm"))
} catch (e: Exception) { "" }

@Composable
fun ChatScreen(vm: AppVm) {
    val chat = vm.openChat ?: return
    BackHandler { vm.closeChat() }
    var text by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    LaunchedEffect(chat.id) {
        while (true) {
            vm.pollMessages()
            delay(3000)
        }
    }
    LaunchedEffect(vm.messages.size) {
        if (vm.messages.isNotEmpty()) listState.animateScrollToItem(vm.messages.lastIndex)
    }
    Column(Modifier.fillMaxSize().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.closeChat() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع") }
            Avatar(chat.title, 36)
            Spacer(Modifier.size(8.dp))
            Text(chat.title, style = MaterialTheme.typography.titleMedium)
        }
        HorizontalDivider()
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, contentPadding = androidx.compose.foundation.layout.PaddingValues(8.dp)) {
            items(vm.messages, key = { it.id }) { m ->
                val mine = m.senderId == vm.me?.id
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 2.dp),
                    horizontalArrangement = if (mine) Arrangement.Start else Arrangement.End
                ) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = if (mine) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.widthIn(max = 280.dp)
                    ) {
                        Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                            if (!mine && chat.isGroup) {
                                Text(vm.nameOf(m.senderId), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                            }
                            Text(m.body ?: "")
                            Text(timeOf(m.createdAt), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = text, onValueChange = { text = it.take(4000) },
                placeholder = { Text("اكتب رسالة") }, modifier = Modifier.weight(1f), maxLines = 4
            )
            IconButton(
                onClick = { vm.send(text); text = "" },
                enabled = text.trim().isNotEmpty()
            ) { Icon(Icons.AutoMirrored.Filled.Send, "إرسال") }
        }
    }
}
