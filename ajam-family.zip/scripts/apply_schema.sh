#!/usr/bin/env bash
# Applies supabase/migrations/*.sql once each, using only the Supabase access token (no DB password).
set -euo pipefail
REF="$1"
API="https://api.supabase.com/v1/projects/$REF"

q() {
  jq -Rs '{query: .}' | curl -sS --fail-with-body -X POST "$API/database/query" \
    -H "Authorization: Bearer $SUPABASE_ACCESS_TOKEN" \
    -H "Content-Type: application/json" -d @-
}

echo "create table if not exists public._ajam_migrations(name text primary key); alter table public._ajam_migrations enable row level security;" | q > /dev/null

for f in supabase/migrations/*.sql; do
  n=$(basename "$f")
  c=$(echo "select count(*) as c from public._ajam_migrations where name='$n';" | q | jq -r '.[0].c')
  if [ "$c" = "0" ]; then
    echo "Applying $n"
    { cat "$f"; echo; echo "insert into public._ajam_migrations(name) values ('$n');"; } | q > /dev/null
  else
    echo "Already applied: $n"
  fi
done

echo "Enabling anonymous sign-ins"
curl -sS --fail-with-body -X PATCH "$API/config/auth" \
  -H "Authorization: Bearer $SUPABASE_ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"external_anonymous_users_enabled": true}' > /dev/null
echo "Database ready."
