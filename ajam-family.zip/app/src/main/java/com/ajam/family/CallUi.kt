package com.ajam.family

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import org.webrtc.EglBase
import org.webrtc.RendererCommon
import org.webrtc.SurfaceViewRenderer
import org.webrtc.VideoTrack

private fun has(ctx: android.content.Context, p: String) =
    ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

/** Returns a function that asks for mic/camera permission if needed, then starts the call. */
@Composable
fun rememberCallStarter(fvm: FeaturesVm): (String, Boolean) -> Unit {
    val ctx = LocalContext.current
    var pending by remember { mutableStateOf<Pair<String, Boolean>?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        val p = pending
        pending = null
        if (p != null) {
            if (res[Manifest.permission.RECORD_AUDIO] == true || has(ctx, Manifest.permission.RECORD_AUDIO)) {
                fvm.startCall(p.first, p.second)
            } else {
                fvm.error = "نحتاج إذن الميكروفون لإجراء المكالمة"
            }
        }
    }
    return { peer, video ->
        val need = ArrayList<String>()
        if (!has(ctx, Manifest.permission.RECORD_AUDIO)) need.add(Manifest.permission.RECORD_AUDIO)
        if (video && !has(ctx, Manifest.permission.CAMERA)) need.add(Manifest.permission.CAMERA)
        if (need.isEmpty()) {
            fvm.startCall(peer, video)
        } else {
            pending = peer to video
            launcher.launch(need.toTypedArray())
        }
    }
}

@Composable
private fun RingEffect(type: Int, alarm: Boolean) {
    val ctx = LocalContext.current
    DisposableEffect(type) {
        val r = try { RingtoneManager.getRingtone(ctx, RingtoneManager.getDefaultUri(type)) } catch (e: Exception) { null }
        try {
            if (r != null) {
                r.audioAttributes = AudioAttributes.Builder()
                    .setUsage(if (alarm) AudioAttributes.USAGE_ALARM else AudioAttributes.USAGE_NOTIFICATION_RINGTONE).build()
                if (Build.VERSION.SDK_INT >= 28) r.isLooping = true
                r.play()
            }
        } catch (e: Exception) { }
        onDispose { try { r?.stop() } catch (e: Exception) { } }
    }
}

@Composable
fun IncomingCallOverlay(vm: AppVm, fvm: FeaturesVm) {
    val c = fvm.incoming ?: return
    val ctx = LocalContext.current
    val p = vm.profileOf(c.callerId)
    RingEffect(RingtoneManager.TYPE_RINGTONE, false)
    val ring = pulse(0.95f, 1.12f, 700)
    var accepting by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (has(ctx, Manifest.permission.RECORD_AUDIO)) fvm.acceptIncoming()
        else { fvm.error = "نحتاج إذن الميكروفون للرد"; fvm.declineIncoming() }
    }
    Column(
        Modifier.fillMaxSize().background(BrandBrush).statusBarsPadding().navigationBarsPadding().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceBetween
    ) {
        Spacer(Modifier.height(24.dp))
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.scale(ring)) { UserAvatar(vm, p, p?.displayName ?: "؟", 120) }
            Spacer(Modifier.height(24.dp))
            Text(p?.displayName ?: "أحد أفراد العائلة", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(if (c.kind == "video") "مكالمة فيديو واردة..." else "مكالمة صوتية واردة...", color = Color.White.copy(alpha = 0.85f), fontSize = 16.sp)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            CallButton("📵", Color(0xFFD32F2F), "رفض") { fvm.declineIncoming() }
            CallButton("📞", Color(0xFF1FA463), "رد") {
                if (accepting) return@CallButton
                accepting = true
                val need = ArrayList<String>()
                if (!has(ctx, Manifest.permission.RECORD_AUDIO)) need.add(Manifest.permission.RECORD_AUDIO)
                if (c.kind == "video" && !has(ctx, Manifest.permission.CAMERA)) need.add(Manifest.permission.CAMERA)
                if (need.isEmpty()) fvm.acceptIncoming() else launcher.launch(need.toTypedArray())
            }
        }
    }
}

@Composable
private fun CallButton(icon: String, color: Color, label: String, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(68.dp).clip(CircleShape).background(color).clickable { onClick() },
            contentAlignment = Alignment.Center
        ) { Text(icon, fontSize = 28.sp) }
        Spacer(Modifier.height(6.dp))
        Text(label, color = Color.White, fontSize = 13.sp)
    }
}

@Composable
private fun VideoSurface(egl: EglBase, track: VideoTrack?, mirror: Boolean, overlay: Boolean, modifier: Modifier) {
    val ctx = LocalContext.current
    val renderer = remember {
        SurfaceViewRenderer(ctx).apply {
            init(egl.eglBaseContext, null)
            setEnableHardwareScaler(true)
            setMirror(mirror)
            setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FILL)
            if (overlay) setZOrderMediaOverlay(true)
        }
    }
    DisposableEffect(track) {
        track?.addSink(renderer)
        onDispose { track?.removeSink(renderer) }
    }
    DisposableEffect(Unit) { onDispose { try { renderer.release() } catch (e: Exception) { } } }
    AndroidView(factory = { renderer }, modifier = modifier)
}

@Composable
fun InCallScreen(vm: AppVm, fvm: FeaturesVm, s: CallSession) {
    BackHandler { }
    val p = vm.profileOf(s.peerId)
    var seconds by remember { mutableStateOf(0) }
    LaunchedEffect(s.connected) {
        if (s.connected) while (true) { delay(1000); seconds++ }
    }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF083D3A), Color(0xFF0B1412))))) {
        if (s.video) {
            VideoSurface(s.egl, s.remoteVideo, false, false, Modifier.fillMaxSize())
            if (s.localVideo != null) {
                VideoSurface(
                    s.egl, s.localVideo, true, true,
                    Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(12.dp).size(width = 110.dp, height = 150.dp)
                        .clip(RoundedCornerShape(14.dp))
                )
            }
        } else {
            Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                UserAvatar(vm, p, p?.displayName ?: "؟", 130)
            }
        }
        Column(
            Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(p?.displayName ?: "", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text(
                if (s.connected) "%02d:%02d".format(seconds / 60, seconds % 60) else s.state,
                color = Color.White.copy(alpha = 0.85f), fontSize = 15.sp, textAlign = TextAlign.Center
            )
        }
        Row(
            Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(24.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically
        ) {
            ToggleBtn(if (s.muted) "🔇" else "🎤", s.muted) { s.toggleMute() }
            ToggleBtn(if (s.speaker) "🔊" else "📱", s.speaker) { s.toggleSpeaker() }
            if (s.video) {
                ToggleBtn("🎥", s.camOff) { s.toggleCam() }
                ToggleBtn("🔄", false) { s.flipCamera() }
            }
            Box(
                Modifier.size(64.dp).clip(CircleShape).background(Color(0xFFD32F2F)).clickable { s.hangup() },
                contentAlignment = Alignment.Center
            ) { Text("📵", fontSize = 26.sp) }
        }
    }
}

@Composable
private fun ToggleBtn(icon: String, active: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(54.dp).clip(CircleShape)
            .background(if (active) Color.White.copy(alpha = 0.9f) else Color.White.copy(alpha = 0.2f)).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { Text(icon, fontSize = 22.sp) }
}

@Composable
fun CallHistoryOverlay(vm: AppVm, fvm: FeaturesVm) {
    BackHandler { fvm.overlay = Overlay.None }
    val starter = rememberCallStarter(fvm)
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Row(Modifier.fillMaxWidth().background(BrandBrush).statusBarsPadding().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { fvm.overlay = Overlay.None }) { Text("✕", color = Color.White, fontSize = 20.sp) }
            Text("سجل المكالمات", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        if (fvm.callHistory.isEmpty()) Text("لا توجد مكالمات بعد 📞", Modifier.padding(24.dp))
        LazyColumn(Modifier.fillMaxSize()) {
            items(fvm.callHistory, key = { it.id }) { c ->
                val p = vm.profileOf(c.otherId)
                val missed = c.status == "missed" || c.status == "declined"
                Row(
                    Modifier.fillMaxWidth().clickable { fvm.overlay = Overlay.None; starter(c.otherId, c.kind == "video") }.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    UserAvatar(vm, p, p?.displayName ?: "؟", 44)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(p?.displayName ?: "", fontWeight = FontWeight.Bold)
                        Text(
                            (if (c.outgoing) "↗ صادرة" else "↙ واردة") + " · " + when (c.status) {
                                "missed" -> if (c.outgoing) "لم يُرد" else "فائتة"
                                "declined" -> "مرفوضة"
                                "ended" -> "تمت"
                                else -> c.status
                            },
                            fontSize = 12.sp, color = if (missed && !c.outgoing) Color(0xFFD32F2F) else MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Text(if (c.kind == "video") "🎥" else "📞", fontSize = 20.sp)
                }
                HorizontalDivider()
            }
        }
    }
}

@Composable
fun SosAlert(vm: AppVm, fvm: FeaturesVm) {
    val s = fvm.sos.firstOrNull { it.userId != vm.me?.id && it.id !in fvm.dismissedSos } ?: return
    RingEffect(RingtoneManager.TYPE_ALARM, true)
    val starter = rememberCallStarter(fvm)
    val beat = pulse(0.95f, 1.1f, 500)
    Column(
        Modifier.fillMaxSize().background(Color(0xFFB71C1C)).statusBarsPadding().navigationBarsPadding().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Text("🚨", fontSize = 88.sp, modifier = Modifier.scale(beat))
        Spacer(Modifier.height(12.dp))
        Text("SOS", color = Color.White, fontSize = 44.sp, fontWeight = FontWeight.Black)
        Text(s.displayName + " يحتاج مساعدة!", color = Color.White, fontSize = 22.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(28.dp))
        androidx.compose.material3.Button(
            onClick = {
                val lat = s.lat; val lng = s.lng
                if (lat != null && lng != null) {
                    fvm.focus = Loc(s.userId, lat, lng)
                    fvm.requestTab = 2
                }
                fvm.dismissSos(s.id)
            },
            modifier = Modifier.fillMaxWidth().height(54.dp)
        ) { Text("📍 عرض موقعه على الخريطة", fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(10.dp))
        androidx.compose.material3.OutlinedButton(
            onClick = { starter(s.userId, false); fvm.dismissSos(s.id) },
            modifier = Modifier.fillMaxWidth().height(54.dp)
        ) { Text("📞 اتصال", color = Color.White, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(10.dp))
        TextButton(onClick = { fvm.dismissSos(s.id) }) { Text("إغلاق التنبيه", color = Color.White) }
    }
}
