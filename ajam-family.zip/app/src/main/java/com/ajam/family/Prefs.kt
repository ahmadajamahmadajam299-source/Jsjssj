package com.ajam.family

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private lateinit var sp: SharedPreferences
    fun init(c: Context) { sp = c.getSharedPreferences("ajam", Context.MODE_PRIVATE) }
    var tourDone: Boolean
        get() = sp.getBoolean("tour_done", false)
        set(v) { sp.edit().putBoolean("tour_done", v).apply() }
    var turnUrl: String
        get() = sp.getString("turn_url", "") ?: ""
        set(v) { sp.edit().putString("turn_url", v.trim()).apply() }
    var turnUser: String
        get() = sp.getString("turn_user", "") ?: ""
        set(v) { sp.edit().putString("turn_user", v.trim()).apply() }
    var turnPass: String
        get() = sp.getString("turn_pass", "") ?: ""
        set(v) { sp.edit().putString("turn_pass", v.trim()).apply() }
}
