package com.ajam.family

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class Captured(val file: File, val isVideo: Boolean)

sealed interface Overlay {
    data object None : Overlay
    data object Hub : Overlay
    data object CallHistory : Overlay
    data class ViewSnap(val snap: InboxSnap) : Overlay
    data class ViewStories(val userId: String) : Overlay
}

class FeaturesVm(app: Application) : AndroidViewModel(app) {
    @Volatile private var enabled = false

    var overlay by mutableStateOf<Overlay>(Overlay.None)
    var captured by mutableStateOf<Captured?>(null)
    var error by mutableStateOf<String?>(null)
    var sending by mutableStateOf(false); private set

    var inbox by mutableStateOf<List<InboxSnap>>(emptyList()); private set
    var stories by mutableStateOf<List<StoryItem>>(emptyList()); private set
    var streaks by mutableStateOf<List<StreakItem>>(emptyList()); private set
    var leaderboard by mutableStateOf<List<ScoreRow>>(emptyList()); private set
    var callHistory by mutableStateOf<List<CallLog>>(emptyList()); private set

    var locations by mutableStateOf<List<Loc>>(emptyList()); private set
    var sharing by mutableStateOf(Sharing()); private set
    var hiddenIds by mutableStateOf<Set<String>>(emptySet()); private set
    @Volatile var mapActive = false
    var focus by mutableStateOf<Loc?>(null)
    var requestTab by mutableStateOf<Int?>(null)

    var sos by mutableStateOf<List<Sos>>(emptyList()); private set
    var dismissedSos by mutableStateOf<Set<String>>(emptySet()); private set
    val mySosActive: Boolean get() = sos.any { it.userId == Repo.uid() }

    var incoming by mutableStateOf<IncomingCall?>(null); private set
    var session by mutableStateOf<CallSession?>(null); private set

    init {
        viewModelScope.launch {
            var tick = 0
            while (true) {
                delay(2000)
                tick++
                if (!enabled || !AppState.foreground || !Repo.hasSession()) continue
                safe { if (session == null) incoming = Api.incomingCall() else incoming = null }
                if (tick % 3 == 0) safe { sos = Api.activeSos() }
                if (tick % 4 == 0) refreshSocial()
                if (mapActive && tick % 2 == 0) safe { locations = Api.familyLocations() }
                if (tick % 5 == 0 && mySosActive) {
                    LocationHelper.lastKnown(getApplication())?.let { l ->
                        safe { Api.updateSos(l.latitude, l.longitude) }
                    }
                }
            }
        }
    }

    private suspend fun safe(block: suspend () -> Unit) {
        try { block() } catch (e: CancellationException) { throw e } catch (e: Exception) { }
    }

    fun enable(b: Boolean) {
        enabled = b
        if (b) viewModelScope.launch { safe { sharing = Api.mySharing() }; safe { hiddenIds = Api.hidden().toSet() }; refreshSocial() }
    }

    fun refreshSocial() {
        viewModelScope.launch {
            safe { inbox = Api.inbox() }
            safe { stories = Api.stories() }
            safe { streaks = Api.streaks() }
        }
    }

    fun refreshLocations() { viewModelScope.launch { safe { locations = Api.familyLocations() } } }
    fun loadScores() { viewModelScope.launch { safe { leaderboard = Api.leaderboard() } } }
    fun loadHistory() { viewModelScope.launch { safe { callHistory = Api.callHistory() } } }

    private fun fail(e: Throwable) {
        val m = e.message ?: ""
        error = when {
            "busy" in m -> "الشخص مشغول في مكالمة أخرى"
            "rate_limited" in m -> "عمليات كثيرة بسرعة، انتظر قليلاً"
            "not_available" in m -> "هذا السناب لم يعد متاحاً"
            else -> friendly(e)
        }
    }

    // ---------- snaps / stories ----------
    fun sendSnap(bytes: ByteArray, isVideo: Boolean, recipients: List<String>, toStory: Boolean, seconds: Int?) {
        val myId = Repo.uid() ?: return
        viewModelScope.launch {
            sending = true
            try {
                val path = "$myId/${java.util.UUID.randomUUID()}." + if (isVideo) "mp4" else "jpg"
                Repo.upload("snaps", path, bytes)
                val kind = if (isVideo) "video" else "photo"
                if (recipients.isNotEmpty()) Api.sendSnap(path, kind, recipients, seconds)
                if (toStory) Api.postStory(path, kind)
                captured = null
                refreshSocial()
            } catch (e: Throwable) {
                if (e is CancellationException) throw e
                fail(e)
            } finally {
                sending = false
            }
        }
    }

    fun sendCapturedVideo(file: File, recipients: List<String>, toStory: Boolean, seconds: Int?) {
        viewModelScope.launch {
            sending = true
            try {
                if (file.length() > Media.MAX_BYTES) { error = "الفيديو كبير جداً"; return@launch }
                val bytes = withContext(Dispatchers.IO) { file.readBytes() }
                sending = false
                sendSnap(bytes, true, recipients, toStory, seconds)
            } catch (e: Throwable) {
                if (e is CancellationException) throw e
                fail(e)
            } finally {
                sending = false
            }
        }
    }

    suspend fun openSnapUrl(id: String): String {
        val path = Api.openSnap(id)
        return Repo.signedUrl("snaps", path)
    }

    fun viewStory(id: String) { viewModelScope.launch { safe { Api.viewStory(id) } } }

    suspend fun viewers(id: String): List<Viewer> = try { Api.storyViewers(id) } catch (e: Exception) { emptyList() }

    fun replyToStory(ownerId: String, text: String) {
        val myId = Repo.uid() ?: return
        viewModelScope.launch {
            try {
                val conv = Repo.direct(ownerId)
                Repo.sendMessage(conv, myId, "↩️ رد على قصتك: " + text.trim(), "text", null)
            } catch (e: Throwable) {
                if (e is CancellationException) throw e
                fail(e)
            }
        }
    }

    // ---------- map ----------
    fun setSharing(enabledNow: Boolean, precise: Boolean) {
        viewModelScope.launch {
            try {
                Api.setSharing(enabledNow, precise)
                sharing = Api.mySharing()
                if (!enabledNow) LocationHelper.stopSharing(getApplication())
            } catch (e: Throwable) {
                if (e is CancellationException) throw e
                fail(e)
            }
        }
    }

    fun setGhost(mode: String, hours: Int?) {
        viewModelScope.launch {
            try { Api.setGhost(mode, hours); sharing = Api.mySharing() } catch (e: Throwable) {
                if (e is CancellationException) throw e
                fail(e)
            }
        }
    }

    fun toggleHidden(userId: String, hide: Boolean) {
        viewModelScope.launch {
            try {
                Api.setHidden(userId, hide)
                hiddenIds = Api.hidden().toSet()
            } catch (e: Throwable) {
                if (e is CancellationException) throw e
                fail(e)
            }
        }
    }

    fun startSos() {
        viewModelScope.launch {
            try {
                val l = LocationHelper.lastKnown(getApplication())
                if (l == null) { error = "تعذر تحديد موقعك. فعّل الموقع وأعد المحاولة."; return@launch }
                Api.startSos(l.latitude, l.longitude)
                sos = Api.activeSos()
            } catch (e: Throwable) {
                if (e is CancellationException) throw e
                fail(e)
            }
        }
    }

    fun endSos() {
        viewModelScope.launch { safe { Api.endSos(); sos = Api.activeSos() } }
    }

    fun dismissSos(id: String) { dismissedSos = dismissedSos + id }

    // ---------- calls ----------
    fun startCall(peerId: String, video: Boolean) {
        if (session != null) return
        viewModelScope.launch {
            try {
                val id = Api.startCall(peerId, if (video) "video" else "audio")
                val s = CallSession(getApplication(), id, peerId, video, true, viewModelScope) { session = null }
                session = s
                s.start()
            } catch (e: Throwable) {
                if (e is CancellationException) throw e
                fail(e)
            }
        }
    }

    fun acceptIncoming() {
        val c = incoming ?: return
        incoming = null
        Notifs.cancel(getApplication(), Notifs.ID_CALL)
        viewModelScope.launch {
            try {
                Api.answerCall(c.id)
                val s = CallSession(getApplication(), c.id, c.callerId, c.kind == "video", false, viewModelScope) { session = null }
                session = s
                s.start()
            } catch (e: Throwable) {
                if (e is CancellationException) throw e
                fail(e)
            }
        }
    }

    fun declineIncoming() {
        val c = incoming ?: return
        incoming = null
        Notifs.cancel(getApplication(), Notifs.ID_CALL)
        viewModelScope.launch { safe { Api.declineCall(c.id) } }
    }
}
