package com.ajam.family

import android.Manifest
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.BitmapDrawable
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.CopyrightOverlay
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.TilesOverlay
import java.time.Duration
import java.time.Instant
import java.time.OffsetDateTime

private fun agoText(iso: String): String {
    val t = try { OffsetDateTime.parse(iso).toInstant() } catch (e: Exception) { return "" }
    val s = Duration.between(t, Instant.now()).seconds
    return when {
        s < 90 -> "الآن"
        s < 3600 -> "${s / 60}د"
        s < 86400 -> "${s / 3600}س"
        else -> "${s / 86400}ي"
    }
}

private fun moveState(speed: Float?): String = when {
    speed == null || speed < 0.7f -> "🧍 واقف"
    speed < 2.8f -> "🚶 يمشي"
    else -> "🚗 يقود"
}

private fun subText(l: Loc): String {
    val b = if (l.battery != null && l.battery >= 0) " · 🔋${l.battery}%" + if (l.charging == true) "⚡" else "" else ""
    return agoText(l.updatedAt) + b
}

private val pinColors = listOf(
    0xFF0F8F6D.toInt(), 0xFF7C4DFF.toInt(), 0xFFFF7043.toInt(), 0xFF29B6F6.toInt(),
    0xFFEC407A.toInt(), 0xFFFFA000.toInt(), 0xFF26A69A.toInt(), 0xFF5C6BC0.toInt()
)

private fun pinBitmap(ctx: Context, name: String, sub: String, online: Boolean): Bitmap {
    val d = ctx.resources.displayMetrics.density
    val w = (160 * d).toInt()
    val h = (96 * d).toInt()
    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val c = AndroidCanvas(bmp)
    val cx = w / 2f
    val cy = 30 * d
    val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = pinColors[(name.hashCode() and 0x7fffffff) % pinColors.size] }
    c.drawCircle(cx, cy, 27 * d, fill)
    val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 3.5f * d
        color = if (online) 0xFF2ED47A.toInt() else android.graphics.Color.WHITE
    }
    c.drawCircle(cx, cy, 27 * d, ring)
    val letter = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.WHITE; textSize = 26 * d; textAlign = Paint.Align.CENTER; isFakeBoldText = true
    }
    c.drawText(name.trim().take(1), cx, cy + 9 * d, letter)

    val np = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.WHITE; textSize = 13 * d; textAlign = Paint.Align.CENTER; isFakeBoldText = true
    }
    val sp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFCCCCCC.toInt(); textSize = 10.5f * d; textAlign = Paint.Align.CENTER
    }
    val tw = maxOf(np.measureText(name), sp.measureText(sub)) + 14 * d
    val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCC111111.toInt() }
    c.drawRoundRect(RectF(cx - tw / 2, 62 * d, cx + tw / 2, 92 * d), 8 * d, 8 * d, bg)
    c.drawText(name, cx, 76 * d, np)
    c.drawText(sub, cx, 88 * d, sp)
    return bmp
}

@Composable
fun MapTab(vm: AppVm, fvm: FeaturesVm, goCamera: () -> Unit) {
    val ctx = LocalContext.current
    val callStarter = rememberCallStarter(fvm)
    var selected by remember { mutableStateOf<String?>(null) }
    var showPrivacy by remember { mutableStateOf(false) }
    var showRationale by remember { mutableStateOf(false) }
    var centered by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        fvm.mapActive = true
        fvm.refreshLocations()
        onDispose { fvm.mapActive = false }
    }

    fun finishEnable() {
        fvm.setSharing(true, fvm.sharing.precise)
        LocationHelper.startSharing(ctx)
    }
    val bgLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { finishEnable() }
    val fgLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (!LocationHelper.hasPermission(ctx)) {
            fvm.error = "لم يتم منح إذن الموقع، لا يمكن مشاركة موقعك."
        } else if (Build.VERSION.SDK_INT >= 29 && !LocationHelper.hasBackground(ctx)) {
            bgLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
        } else {
            finishEnable()
        }
    }

    val mapView = remember {
        Configuration.getInstance().load(ctx, ctx.getSharedPreferences("osmdroid", Context.MODE_PRIVATE))
        Configuration.getInstance().userAgentValue = ctx.packageName
        MapView(ctx).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
            controller.setZoom(4.0)
            controller.setCenter(GeoPoint(30.0, 40.0))
            overlayManager.tilesOverlay.setColorFilter(TilesOverlay.INVERT_COLORS)
            overlays.add(CopyrightOverlay(ctx))
        }
    }
    DisposableEffect(Unit) {
        mapView.onResume()
        onDispose { mapView.onPause() }
    }
    DisposableEffect(Unit) { onDispose { mapView.onDetach() } }

    val locs = fvm.locations
    val members = vm.members
    val myId = vm.me?.id
    LaunchedEffect(locs.size) {
        if (!centered) {
            val mine = locs.firstOrNull { it.userId == myId } ?: locs.firstOrNull()
            if (mine != null) {
                mapView.controller.setZoom(16.0)
                mapView.controller.animateTo(GeoPoint(mine.lat, mine.lng))
                centered = true
            }
        }
    }
    LaunchedEffect(fvm.focus) {
        fvm.focus?.let {
            mapView.controller.setZoom(17.0)
            mapView.controller.animateTo(GeoPoint(it.lat, it.lng))
            selected = it.userId
        }
    }

    Box(Modifier.fillMaxSize()) {
        AndroidView(
            factory = { mapView },
            modifier = Modifier.fillMaxSize(),
            update = { mv ->
                mv.overlays.removeAll { it is Marker }
                for (l in locs) {
                    val p = members.firstOrNull { it.id == l.userId }
                    val name = p?.displayName ?: "؟"
                    val online = agoText(l.updatedAt) == "الآن"
                    val m = Marker(mv)
                    m.position = GeoPoint(l.lat, l.lng)
                    m.icon = BitmapDrawable(ctx.resources, pinBitmap(ctx, name, subText(l), online))
                    m.setAnchor(Marker.ANCHOR_CENTER, 0.32f)
                    m.setOnMarkerClickListener { _, _ -> selected = l.userId; true }
                    mv.overlays.add(m)
                }
                mv.invalidate()
            }
        )

        // top controls
        Card(
            Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(12.dp).fillMaxWidth()
        ) {
            Row(Modifier.padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("مشاركة موقعي", fontWeight = FontWeight.Bold)
                    val g = fvm.sharing
                    Text(
                        if (!g.enabled) "متوقفة" else when (g.ghost) {
                            "hide" -> "👻 أنت مخفي"
                            "freeze" -> "🧊 موقعك مجمّد"
                            else -> "مفعّلة"
                        },
                        fontSize = 12.sp
                    )
                }
                TextButton(onClick = { showPrivacy = true }) { Text("👻 الخصوصية") }
                Switch(
                    checked = fvm.sharing.enabled,
                    onCheckedChange = { on ->
                        if (!on) {
                            fvm.setSharing(false, fvm.sharing.precise)
                        } else if (!LocationHelper.hasPermission(ctx) ||
                            (Build.VERSION.SDK_INT >= 29 && !LocationHelper.hasBackground(ctx))
                        ) {
                            showRationale = true
                        } else {
                            finishEnable()
                        }
                    }
                )
            }
        }

        // recenter
        Box(
            Modifier.align(Alignment.CenterEnd).padding(12.dp).size(46.dp).clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.6f))
                .clickable {
                    val mine = locs.firstOrNull { it.userId == myId }
                    if (mine != null) {
                        mapView.controller.animateTo(GeoPoint(mine.lat, mine.lng))
                        mapView.controller.setZoom(16.0)
                    }
                },
            contentAlignment = Alignment.Center
        ) { Text("🎯", fontSize = 22.sp) }

        // SOS
        Column(Modifier.align(Alignment.BottomStart).padding(16.dp)) {
            if (selected == null) {
                if (fvm.mySosActive) {
                    Button(
                        onClick = { fvm.endSos() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1FA463)),
                        modifier = Modifier.height(56.dp)
                    ) { Text("أنا بخير ✓", fontWeight = FontWeight.Bold, fontSize = 17.sp) }
                } else {
                    Box(
                        Modifier.size(68.dp).clip(CircleShape).background(Color(0xFFD32F2F))
                            .pointerInput(Unit) {
                                detectTapGestures(
                                    onTap = { fvm.error = "اضغط مطولاً على زر SOS لإرسال التنبيه لكل العائلة" },
                                    onLongPress = { fvm.startSos() }
                                )
                            },
                        contentAlignment = Alignment.Center
                    ) { Text("SOS", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp) }
                }
            }
        }

        // selected member sheet
        val sel = selected
        if (sel != null) {
            val l = locs.firstOrNull { it.userId == sel }
            val p = vm.profileOf(sel)
            if (l != null) {
                Card(Modifier.align(Alignment.BottomCenter).padding(12.dp).fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            UserAvatar(vm, p, p?.displayName ?: "؟", 48)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(p?.displayName ?: "", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                Text(moveState(l.speed) + " · " + subText(l), fontSize = 12.sp)
                            }
                            TextButton(onClick = { selected = null }) { Text("✕") }
                        }
                        Spacer(Modifier.height(8.dp))
                        if (sel != myId) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                OutlinedButton(onClick = { vm.startDirect(sel) }) { Text("💬") }
                                OutlinedButton(onClick = { callStarter(sel, false) }) { Text("📞") }
                                OutlinedButton(onClick = { callStarter(sel, true) }) { Text("🎥") }
                                OutlinedButton(onClick = { goCamera() }) { Text("📸") }
                                OutlinedButton(onClick = {
                                    val uri = Uri.parse("geo:${l.lat},${l.lng}?q=${l.lat},${l.lng}(" + Uri.encode(p?.displayName ?: "") + ")")
                                    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (e: Exception) {
                                        fvm.error = "لا يوجد تطبيق خرائط مثبت"
                                    }
                                }) { Text("🧭") }
                            }
                            Text("💬 دردشة · 📞 صوت · 🎥 فيديو · 📸 سناب · 🧭 الاتجاهات", fontSize = 10.sp)
                        }
                    }
                }
            }
        }

        if (locs.isEmpty()) {
            Text(
                "لا توجد مواقع بعد.\nفعّل مشاركة موقعك، وعندما يفعّلها أفراد العائلة سيظهرون هنا.",
                Modifier.align(Alignment.Center).padding(32.dp).background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(16.dp)).padding(16.dp),
                color = Color.White, textAlign = TextAlign.Center
            )
        }
    }

    if (showRationale) {
        AlertDialog(
            onDismissRequest = { showRationale = false },
            title = { Text("مشاركة الموقع") },
            text = {
                Text(
                    "لعرض موقعك لعائلتك نحتاج إذن الموقع. اختر «السماح طوال الوقت» ليستمر تحديث موقعك حتى عندما يكون التطبيق مغلقاً.\n\n" +
                        "الموقع لا يُشارك إلا بعد تفعيلك له، ويمكنك إيقافه أو التخفي (وضع الشبح) أو الإخفاء عن أشخاص محددين في أي وقت. " +
                        "يعمل التحديث بفترات ذكية لتوفير البطارية."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showRationale = false
                    if (!LocationHelper.hasPermission(ctx)) {
                        fgLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                    } else if (Build.VERSION.SDK_INT >= 29 && !LocationHelper.hasBackground(ctx)) {
                        bgLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                    } else {
                        finishEnable()
                    }
                }) { Text("متابعة") }
            },
            dismissButton = { TextButton(onClick = { showRationale = false }) { Text("إلغاء") } }
        )
    }

    if (showPrivacy) PrivacyDialog(vm, fvm) { showPrivacy = false }
}

@Composable
private fun PrivacyDialog(vm: AppVm, fvm: FeaturesVm, onClose: () -> Unit) {
    val others = vm.members.filter { it.id != vm.me?.id && it.status == "active" }
    val g = fvm.sharing
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("الخصوصية ووضع الشبح") },
        text = {
            LazyColumn(Modifier.height(420.dp)) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("موقع دقيق", fontWeight = FontWeight.Bold)
                            Text(if (g.precise) "يرى الجميع موقعك بدقة" else "يظهر موقعك تقريبياً (حوالي 1 كم)", fontSize = 11.sp)
                        }
                        Switch(checked = g.precise, onCheckedChange = { fvm.setSharing(g.enabled, it) })
                    }
                    Spacer(Modifier.height(10.dp))
                    Text("وضع الشبح 👻", fontWeight = FontWeight.Bold)
                    Text(
                        when (g.ghost) {
                            "hide" -> "الحالة: مخفي"
                            "freeze" -> "الحالة: مجمّد"
                            else -> "الحالة: معطّل"
                        },
                        fontSize = 12.sp
                    )
                }
                val opts = listOf(
                    Triple("إيقاف الشبح", "off", null as Int?),
                    Triple("إخفاء لمدة ساعة", "hide", 1 as Int?),
                    Triple("إخفاء 8 ساعات", "hide", 8 as Int?),
                    Triple("إخفاء حتى أوقفه", "hide", null as Int?),
                    Triple("تجميد ساعة", "freeze", 1 as Int?),
                    Triple("تجميد 8 ساعات", "freeze", 8 as Int?),
                    Triple("تجميد حتى أوقفه", "freeze", null as Int?)
                )
                items(opts) { (label, mode, hrs) ->
                    TextButton(onClick = { fvm.setGhost(mode, hrs) }) { Text(label) }
                }
                item {
                    Spacer(Modifier.height(8.dp))
                    Text("إخفاء موقعي عن أشخاص محددين", fontWeight = FontWeight.Bold)
                }
                items(others, key = { it.id }) { p ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(p.id in fvm.hiddenIds, { fvm.toggleHidden(p.id, it) })
                        Text(p.displayName)
                    }
                }
                item { Text("«الإخفاء» يخفيك، و«التجميد» يُبقي آخر موقع معروف دون تحديث.", fontSize = 11.sp) }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("تم") } }
    )
}
