-- Phase 1: identity, family, chat. Every table has RLS enabled.
create extension if not exists citext;

create table public.families (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 60),
  join_code text not null unique,
  created_by uuid,
  created_at timestamptz not null default now()
);

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null check (char_length(display_name) between 1 and 40),
  username citext unique check (username ~ '^[a-z0-9_.]{3,24}$'),
  family_id uuid references public.families(id),
  role text not null default 'member' check (role in ('admin','member')),
  status text not null default 'none' check (status in ('none','pending','active')),
  avatar_path text,
  bio text not null default '',
  hide_last_seen boolean not null default false,
  last_seen_at timestamptz,
  created_at timestamptz not null default now()
);

-- Permanent global reservation. No FK on purpose: survives account deletion.
create table public.reserved_usernames (
  username citext primary key,
  user_id uuid not null,
  reserved_at timestamptz not null default now()
);

create table public.recovery_codes (
  user_id uuid primary key,
  code_hash text not null,
  created_at timestamptz not null default now()
);

create table public.conversations (
  id uuid primary key default gen_random_uuid(),
  family_id uuid not null references public.families(id),
  kind text not null check (kind in ('direct','group')),
  name text,
  avatar_path text,
  admin_only boolean not null default false,
  created_by uuid not null,
  created_at timestamptz not null default now()
);

create table public.conversation_members (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  role text not null default 'member' check (role in ('admin','member')),
  muted boolean not null default false,
  pinned boolean not null default false,
  last_read_at timestamptz not null default now(),
  primary key (conversation_id, user_id)
);

create table public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references public.profiles(id),
  kind text not null default 'text' check (kind in ('text','voice','image','video','file')),
  body text check (char_length(body) <= 4000),
  media_path text,
  reply_to uuid references public.messages(id) on delete set null,
  forwarded boolean not null default false,
  edited_at timestamptz,
  deleted_at timestamptz,
  created_at timestamptz not null default now()
);
create index on public.messages (conversation_id, created_at desc);

create table public.message_receipts (
  message_id uuid not null references public.messages(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  delivered_at timestamptz,
  read_at timestamptz,
  primary key (message_id, user_id)
);

create table public.message_reactions (
  message_id uuid not null references public.messages(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  emoji text not null check (char_length(emoji) <= 16),
  primary key (message_id, user_id)
);

create table public.message_stars (
  message_id uuid not null references public.messages(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  primary key (message_id, user_id)
);

create table public.blocks (
  blocker_id uuid not null references public.profiles(id) on delete cascade,
  blocked_id uuid not null references public.profiles(id) on delete cascade,
  primary key (blocker_id, blocked_id)
);

create table public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  target_user_id uuid,
  target_message_id uuid,
  reason text not null check (char_length(reason) <= 500),
  created_at timestamptz not null default now()
);

-- ---------- helper functions ----------
create function public.my_family_id() returns uuid
language sql stable security definer set search_path = public as $$
  select family_id from public.profiles where id = auth.uid() and status = 'active'
$$;

create function public.is_family_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles
    where id = auth.uid() and status = 'active' and role = 'admin')
$$;

create function public.is_member(conv uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.conversation_members cm
    join public.conversations c on c.id = cm.conversation_id
    where cm.conversation_id = conv and cm.user_id = auth.uid()
      and c.family_id = public.my_family_id())
$$;

create function public.is_conv_admin(conv uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.conversation_members cm
    where cm.conversation_id = conv and cm.user_id = auth.uid() and cm.role = 'admin')
$$;

-- ---------- identity RPCs ----------
create function public.create_profile(p_name text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  insert into public.profiles (id, display_name) values (auth.uid(), trim(p_name))
  on conflict (id) do nothing;
end $$;

create function public.username_available(p_username text) returns boolean
language sql stable security definer set search_path = public as $$
  select lower(p_username) ~ '^[a-z0-9_.]{3,24}$'
    and not exists (select 1 from public.reserved_usernames where username = lower(p_username))
$$;

create function public.claim_username(p_username text) returns void
language plpgsql security definer set search_path = public as $$
declare u text := lower(trim(p_username));
begin
  if u !~ '^[a-z0-9_.]{3,24}$' then raise exception 'invalid_username'; end if;
  if exists (select 1 from public.profiles where id = auth.uid() and username is not null) then
    raise exception 'username_permanent';
  end if;
  begin
    insert into public.reserved_usernames (username, user_id) values (u, auth.uid());
  exception when unique_violation then
    raise exception 'username_taken';
  end;
  update public.profiles set username = u where id = auth.uid();
end $$;

-- ---------- family RPCs ----------
create function public.create_family(p_name text) returns table (family_id uuid, join_code text)
language plpgsql security definer set search_path = public as $$
declare fid uuid; code text;
begin
  if exists (select 1 from public.profiles where id = auth.uid() and status <> 'none') then
    raise exception 'already_in_family';
  end if;
  code := upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 8));
  insert into public.families (name, join_code, created_by) values (trim(p_name), code, auth.uid())
    returning id into fid;
  update public.profiles set family_id = fid, role = 'admin', status = 'active' where id = auth.uid();
  return query select fid, code;
end $$;

create function public.join_family(p_code text) returns text
language plpgsql security definer set search_path = public as $$
declare f public.families;
begin
  if exists (select 1 from public.profiles where id = auth.uid() and status <> 'none') then
    raise exception 'already_in_family';
  end if;
  select * into f from public.families where join_code = upper(trim(p_code));
  if not found then raise exception 'invalid_code'; end if;
  update public.profiles set family_id = f.id, status = 'pending', role = 'member' where id = auth.uid();
  return f.name;
end $$;

create function public.get_join_code() returns text
language sql stable security definer set search_path = public as $$
  select f.join_code from public.families f
  where f.id = public.my_family_id() and public.is_family_admin()
$$;

create function public.regenerate_join_code() returns text
language plpgsql security definer set search_path = public as $$
declare code text;
begin
  if not public.is_family_admin() then raise exception 'admin_only'; end if;
  code := upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 8));
  update public.families set join_code = code where id = public.my_family_id();
  return code;
end $$;

create function public.approve_member(p_user uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_family_admin() then raise exception 'admin_only'; end if;
  update public.profiles set status = 'active'
   where id = p_user and family_id = public.my_family_id() and status = 'pending';
end $$;

create function public.promote_admin(p_user uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_family_admin() then raise exception 'admin_only'; end if;
  update public.profiles set role = 'admin'
   where id = p_user and family_id = public.my_family_id() and status = 'active';
end $$;

create function public.remove_member(p_user uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_family_admin() then raise exception 'admin_only'; end if;
  if p_user = auth.uid() then raise exception 'cannot_remove_self'; end if;
  delete from public.conversation_members cm
   using public.conversations c
   where cm.conversation_id = c.id and cm.user_id = p_user and c.family_id = public.my_family_id();
  update public.profiles set family_id = null, status = 'none', role = 'member'
   where id = p_user and family_id = public.my_family_id();
end $$;

-- ---------- chat RPCs ----------
create function public.get_or_create_direct(p_other uuid) returns uuid
language plpgsql security definer set search_path = public as $$
declare cid uuid; fid uuid := public.my_family_id();
begin
  if fid is null then raise exception 'no_family'; end if;
  if not exists (select 1 from public.profiles where id = p_other and family_id = fid and status = 'active') then
    raise exception 'not_in_family';
  end if;
  select c.id into cid from public.conversations c
   where c.kind = 'direct' and c.family_id = fid
     and exists (select 1 from public.conversation_members m where m.conversation_id = c.id and m.user_id = auth.uid())
     and exists (select 1 from public.conversation_members m where m.conversation_id = c.id and m.user_id = p_other)
   limit 1;
  if cid is null then
    insert into public.conversations (family_id, kind, created_by) values (fid, 'direct', auth.uid())
      returning id into cid;
    insert into public.conversation_members (conversation_id, user_id) values (cid, auth.uid()), (cid, p_other);
  end if;
  return cid;
end $$;

create function public.create_group(p_name text, p_members uuid[]) returns uuid
language plpgsql security definer set search_path = public as $$
declare cid uuid; fid uuid := public.my_family_id(); m uuid;
begin
  if fid is null then raise exception 'no_family'; end if;
  insert into public.conversations (family_id, kind, name, created_by)
    values (fid, 'group', trim(p_name), auth.uid()) returning id into cid;
  insert into public.conversation_members (conversation_id, user_id, role) values (cid, auth.uid(), 'admin');
  foreach m in array p_members loop
    if m <> auth.uid() and exists (select 1 from public.profiles where id = m and family_id = fid and status = 'active') then
      insert into public.conversation_members (conversation_id, user_id) values (cid, m) on conflict do nothing;
    end if;
  end loop;
  return cid;
end $$;

-- ---------- triggers ----------
create function public.messages_guard() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    if (select count(*) from public.messages
         where sender_id = new.sender_id and created_at > now() - interval '10 seconds') >= 30 then
      raise exception 'rate_limited';
    end if;
  elsif tg_op = 'UPDATE' then
    if new.body is distinct from old.body then new.edited_at := now(); end if;
  end if;
  return new;
end $$;
create trigger trg_messages_guard before insert or update on public.messages
  for each row execute function public.messages_guard();

-- ---------- RLS ----------
alter table public.families enable row level security;
alter table public.profiles enable row level security;
alter table public.reserved_usernames enable row level security;
alter table public.recovery_codes enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;
alter table public.message_receipts enable row level security;
alter table public.message_reactions enable row level security;
alter table public.message_stars enable row level security;
alter table public.blocks enable row level security;
alter table public.reports enable row level security;

-- Clients never touch these directly (server functions only): no policies = no access.
-- reserved_usernames, recovery_codes

create policy families_select on public.families for select using (id = public.my_family_id());
revoke all on public.families from anon, authenticated;
grant select (id, name, created_at) on public.families to authenticated;

create policy profiles_select on public.profiles for select using (
  id = auth.uid()
  or (family_id = public.my_family_id() and (status = 'active' or public.is_family_admin())));
create policy profiles_update on public.profiles for update using (id = auth.uid()) with check (id = auth.uid());
revoke insert, update, delete on public.profiles from anon, authenticated;
grant update (display_name, bio, avatar_path, hide_last_seen, last_seen_at) on public.profiles to authenticated;

create policy conv_select on public.conversations for select using (public.is_member(id));
create policy conv_update on public.conversations for update
  using (public.is_member(id) and kind = 'group' and public.is_conv_admin(id))
  with check (public.is_conv_admin(id));
revoke insert, delete on public.conversations from anon, authenticated;
revoke update on public.conversations from anon, authenticated;
grant update (name, avatar_path, admin_only) on public.conversations to authenticated;

create policy cm_select on public.conversation_members for select using (public.is_member(conversation_id));
create policy cm_update_own on public.conversation_members for update
  using (user_id = auth.uid()) with check (user_id = auth.uid());
revoke insert, delete on public.conversation_members from anon, authenticated;
revoke update on public.conversation_members from anon, authenticated;
grant update (muted, pinned, last_read_at) on public.conversation_members to authenticated;

create policy msg_select on public.messages for select using (public.is_member(conversation_id));
create policy msg_insert on public.messages for insert with check (
  sender_id = auth.uid() and public.is_member(conversation_id)
  and (not (select admin_only from public.conversations where id = conversation_id)
       or public.is_conv_admin(conversation_id)));
create policy msg_update_own on public.messages for update
  using (sender_id = auth.uid()) with check (sender_id = auth.uid());
revoke update on public.messages from anon, authenticated;
grant update (body, deleted_at) on public.messages to authenticated;

create policy rcpt_select on public.message_receipts for select using (
  exists (select 1 from public.messages m where m.id = message_id and public.is_member(m.conversation_id)));
create policy rcpt_insert on public.message_receipts for insert with check (
  user_id = auth.uid() and exists (select 1 from public.messages m where m.id = message_id and public.is_member(m.conversation_id)));
create policy rcpt_update on public.message_receipts for update using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy react_select on public.message_reactions for select using (
  exists (select 1 from public.messages m where m.id = message_id and public.is_member(m.conversation_id)));
create policy react_insert on public.message_reactions for insert with check (
  user_id = auth.uid() and exists (select 1 from public.messages m where m.id = message_id and public.is_member(m.conversation_id)));
create policy react_update on public.message_reactions for update using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy react_delete on public.message_reactions for delete using (user_id = auth.uid());

create policy star_all on public.message_stars for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy blocks_all on public.blocks for all using (blocker_id = auth.uid()) with check (blocker_id = auth.uid());
create policy reports_insert on public.reports for insert with check (reporter_id = auth.uid());
create policy reports_select on public.reports for select using (
  public.is_family_admin() and exists (select 1 from public.profiles p
    where p.id = reporter_id and p.family_id = public.my_family_id()));

grant execute on function public.create_profile, public.username_available, public.claim_username,
  public.create_family, public.join_family, public.get_join_code, public.regenerate_join_code,
  public.approve_member, public.promote_admin, public.remove_member,
  public.get_or_create_direct, public.create_group to authenticated;

-- ---------- storage (private buckets, access by signed URL) ----------
insert into storage.buckets (id, name, public) values
  ('chat-media', 'chat-media', false), ('avatars', 'avatars', false)
on conflict (id) do nothing;

create policy chat_media_select on storage.objects for select to authenticated
  using (bucket_id = 'chat-media' and public.is_member(((storage.foldername(name))[1])::uuid));
create policy chat_media_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'chat-media' and public.is_member(((storage.foldername(name))[1])::uuid));
create policy avatars_select on storage.objects for select to authenticated
  using (bucket_id = 'avatars' and (
    ((storage.foldername(name))[1])::uuid = auth.uid()
    or exists (select 1 from public.profiles p
      where p.id = ((storage.foldername(name))[1])::uuid and p.family_id = public.my_family_id())));
create policy avatars_write on storage.objects for insert to authenticated
  with check (bucket_id = 'avatars' and ((storage.foldername(name))[1])::uuid = auth.uid());
create policy avatars_update on storage.objects for update to authenticated
  using (bucket_id = 'avatars' and ((storage.foldername(name))[1])::uuid = auth.uid());

-- ---------- realtime ----------
alter publication supabase_realtime add table
  public.messages, public.message_receipts, public.message_reactions,
  public.conversation_members, public.profiles;
