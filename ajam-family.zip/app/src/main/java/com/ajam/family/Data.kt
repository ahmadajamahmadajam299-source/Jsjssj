package com.ajam.family

import io.github.jan.supabase.auth.Auth
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.postgrest.query.Order
import io.github.jan.supabase.storage.Storage
import io.github.jan.supabase.storage.storage
import kotlin.time.Duration.Companion.hours
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.add

object Supa {
    val client by lazy {
        createSupabaseClient(BuildConfig.SUPABASE_URL, BuildConfig.SUPABASE_KEY) {
            install(Auth)
            install(Postgrest)
            install(Storage)
        }
    }
}

@Serializable
data class Profile(
    val id: String,
    @SerialName("display_name") val displayName: String,
    val username: String? = null,
    @SerialName("family_id") val familyId: String? = null,
    val role: String = "member",
    val status: String = "none",
    val bio: String = "",
    @SerialName("last_seen_at") val lastSeenAt: String? = null,
    @SerialName("hide_last_seen") val hideLastSeen: Boolean = false,
    @SerialName("avatar_path") val avatarPath: String? = null
)

@Serializable
data class Receipt(
    @SerialName("msg_id") val msgId: String,
    @SerialName("is_delivered") val delivered: Boolean = false,
    @SerialName("is_read") val read: Boolean = false
)

@Serializable
data class Conversation(
    val id: String,
    val kind: String,
    val name: String? = null
)

@Serializable
data class ConvMember(
    @SerialName("conversation_id") val conversationId: String,
    @SerialName("user_id") val userId: String
)

@Serializable
data class Message(
    val id: String,
    @SerialName("conversation_id") val conversationId: String,
    @SerialName("sender_id") val senderId: String,
    val kind: String = "text",
    val body: String? = null,
    @SerialName("media_path") val mediaPath: String? = null,
    @SerialName("created_at") val createdAt: String = ""
)

@Serializable
data class NewMessage(
    @SerialName("conversation_id") val conversationId: String,
    @SerialName("sender_id") val senderId: String,
    val body: String? = null,
    val kind: String = "text",
    @SerialName("media_path") val mediaPath: String? = null
)

object Repo {
    private val db get() = Supa.client

    suspend fun awaitInit() { db.auth.awaitInitialization() }
    fun hasSession(): Boolean = db.auth.currentSessionOrNull() != null
    suspend fun ensureSession() { if (!hasSession()) db.auth.signInAnonymously() }
    fun uid(): String? = db.auth.currentUserOrNull()?.id

    suspend fun rpc(fn: String, params: JsonObject = buildJsonObject { }) =
        db.postgrest.rpc(fn, params)

    suspend fun myProfile(): Profile? {
        val id = uid() ?: return null
        return db.from("profiles").select { filter { eq("id", id) } }.decodeSingleOrNull<Profile>()
    }

    suspend fun createProfile(name: String) { rpc("create_profile", buildJsonObject { put("p_name", name) }) }
    suspend fun usernameAvailable(u: String): Boolean =
        rpc("username_available", buildJsonObject { put("p_username", u) }).decodeAs<Boolean>()
    suspend fun claimUsername(u: String) { rpc("claim_username", buildJsonObject { put("p_username", u) }) }
    suspend fun createFamily(name: String) { rpc("create_family", buildJsonObject { put("p_name", name) }) }
    suspend fun joinFamily(code: String) { rpc("join_family", buildJsonObject { put("p_code", code) }) }
    suspend fun joinCode(): String = rpc("get_join_code").decodeAs<String>()
    suspend fun newJoinCode(): String = rpc("regenerate_join_code").decodeAs<String>()
    suspend fun approve(id: String) { rpc("approve_member", buildJsonObject { put("p_user", id) }) }
    suspend fun promote(id: String) { rpc("promote_admin", buildJsonObject { put("p_user", id) }) }
    suspend fun remove(id: String) { rpc("remove_member", buildJsonObject { put("p_user", id) }) }

    suspend fun members(): List<Profile> = db.from("profiles").select().decodeList<Profile>()
    suspend fun conversations(): List<Conversation> = db.from("conversations").select().decodeList<Conversation>()
    suspend fun convMembers(): List<ConvMember> = db.from("conversation_members").select().decodeList<ConvMember>()

    suspend fun direct(other: String): String =
        rpc("get_or_create_direct", buildJsonObject { put("p_other", other) }).decodeAs<String>()

    suspend fun createGroup(name: String, ids: List<String>): String =
        rpc("create_group", buildJsonObject {
            put("p_name", name)
            putJsonArray("p_members") { ids.forEach { add(it) } }
        }).decodeAs<String>()

    suspend fun messages(convId: String): List<Message> =
        db.from("messages").select {
            filter { eq("conversation_id", convId) }
            order("created_at", Order.DESCENDING)
            limit(200)
        }.decodeList<Message>().reversed()

    suspend fun send(convId: String, senderId: String, text: String) {
        db.from("messages").insert(NewMessage(convId, senderId, text))
    }

    suspend fun upload(bucket: String, path: String, bytes: ByteArray) {
        db.storage.from(bucket).upload(path, bytes) { upsert = false }
    }

    suspend fun signedUrl(bucket: String, path: String): String =
        db.storage.from(bucket).createSignedUrl(path, 1.hours)

    suspend fun sendMessage(convId: String, senderId: String, body: String?, kind: String, path: String?) {
        db.from("messages").insert(NewMessage(convId, senderId, body, kind, path))
    }

    suspend fun setAvatar(id: String, path: String) {
        db.from("profiles").update(buildJsonObject { put("avatar_path", path) }) { filter { eq("id", id) } }
    }

    suspend fun touch(id: String) {
        db.from("profiles").update(buildJsonObject {
            put("last_seen_at", java.time.Instant.now().toString())
        }) { filter { eq("id", id) } }
    }

    suspend fun setHide(id: String, hide: Boolean) {
        db.from("profiles").update(buildJsonObject { put("hide_last_seen", hide) }) { filter { eq("id", id) } }
    }

    suspend fun markDelivered() { rpc("mark_delivered") }
    suspend fun markRead(convId: String) { rpc("mark_read", buildJsonObject { put("p_conv", convId) }) }
    suspend fun receipts(convId: String): List<Receipt> =
        rpc("get_receipts", buildJsonObject { put("p_conv", convId) }).decodeList<Receipt>()

    suspend fun updateProfile(id: String, name: String, bio: String) {
        db.from("profiles").update(buildJsonObject {
            put("display_name", name)
            put("bio", bio)
        }) { filter { eq("id", id) } }
    }
}
