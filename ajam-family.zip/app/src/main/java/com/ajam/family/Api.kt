package com.ajam.family

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.add
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray

@Serializable
data class InboxSnap(
    @SerialName("snap_id") val snapId: String,
    @SerialName("sender_id") val senderId: String,
    val kind: String,
    @SerialName("view_seconds") val viewSeconds: Int? = null,
    @SerialName("view_count") val viewCount: Int = 0,
    @SerialName("created_at") val createdAt: String = ""
)

@Serializable
data class StoryItem(
    @SerialName("story_id") val storyId: String,
    @SerialName("user_id") val userId: String,
    val kind: String,
    @SerialName("media_path") val mediaPath: String,
    @SerialName("created_at") val createdAt: String = "",
    val viewed: Boolean = false
)

@Serializable
data class StreakItem(
    @SerialName("other_id") val otherId: String,
    @SerialName("day_count") val dayCount: Int,
    val alive: Boolean = true,
    val warn: Boolean = false,
    @SerialName("i_sent") val iSent: Boolean = false,
    @SerialName("they_sent") val theySent: Boolean = false
)

@Serializable
data class ScoreRow(
    @SerialName("user_id") val userId: String,
    @SerialName("display_name") val displayName: String,
    val points: Int = 0
)

@Serializable
data class Viewer(
    @SerialName("viewer_id") val viewerId: String,
    @SerialName("viewed_at") val viewedAt: String = ""
)

@Serializable
data class Sharing(
    val enabled: Boolean = false,
    val precise: Boolean = true,
    val ghost: String = "off",
    @SerialName("ghost_until") val ghostUntil: String? = null
)

@Serializable
data class Loc(
    @SerialName("user_id") val userId: String,
    val lat: Double,
    val lng: Double,
    val speed: Float? = null,
    val battery: Int? = null,
    val charging: Boolean? = null,
    @SerialName("updated_at") val updatedAt: String = ""
)

@Serializable
data class HiddenRow(@SerialName("hidden_user") val hiddenUser: String)

@Serializable
data class Sos(
    val id: String,
    @SerialName("user_id") val userId: String,
    val lat: Double? = null,
    val lng: Double? = null,
    @SerialName("created_at") val createdAt: String = "",
    @SerialName("display_name") val displayName: String = ""
)

@Serializable
data class IncomingCall(
    val id: String,
    @SerialName("caller_id") val callerId: String,
    val kind: String
)

@Serializable
data class Signal(
    val id: Long,
    @SerialName("from_id") val fromId: String,
    val kind: String,
    val payload: JsonObject
)

@Serializable
data class CallLog(
    val id: String,
    @SerialName("other_id") val otherId: String,
    val kind: String,
    val status: String,
    val outgoing: Boolean = false,
    @SerialName("created_at") val createdAt: String = ""
)

@Serializable
data class Unread(
    @SerialName("conv_id") val convId: String,
    val title: String = "",
    val unread: Int = 0,
    @SerialName("last_msg_id") val lastMsgId: String? = null,
    @SerialName("last_body") val lastBody: String? = null,
    @SerialName("last_kind") val lastKind: String? = null,
    val muted: Boolean = false
)

object Api {
    private suspend fun r(fn: String, p: JsonObject = buildJsonObject { }) = Repo.rpc(fn, p)

    // snaps / stories / score
    suspend fun sendSnap(path: String, kind: String, recipients: List<String>, seconds: Int?): String =
        r("send_snap", buildJsonObject {
            put("p_path", path)
            put("p_kind", kind)
            putJsonArray("p_recipients") { recipients.forEach { add(it) } }
            if (seconds != null) put("p_seconds", seconds)
        }).decodeAs<String>()

    suspend fun inbox(): List<InboxSnap> = r("get_inbox").decodeList<InboxSnap>()
    suspend fun openSnap(id: String): String = r("open_snap", buildJsonObject { put("p_snap", id) }).decodeAs<String>()
    suspend fun postStory(path: String, kind: String): String =
        r("post_story", buildJsonObject { put("p_path", path); put("p_kind", kind) }).decodeAs<String>()
    suspend fun stories(): List<StoryItem> = r("get_stories").decodeList<StoryItem>()
    suspend fun viewStory(id: String) { r("view_story", buildJsonObject { put("p_story", id) }) }
    suspend fun storyViewers(id: String): List<Viewer> =
        r("get_story_viewers", buildJsonObject { put("p_story", id) }).decodeList<Viewer>()
    suspend fun leaderboard(): List<ScoreRow> = r("get_leaderboard").decodeList<ScoreRow>()
    suspend fun streaks(): List<StreakItem> = r("get_streaks").decodeList<StreakItem>()

    // map
    suspend fun mySharing(): Sharing = r("get_my_sharing").decodeList<Sharing>().firstOrNull() ?: Sharing()
    suspend fun setSharing(enabled: Boolean, precise: Boolean) {
        r("set_sharing", buildJsonObject { put("p_enabled", enabled); put("p_precise", precise) })
    }
    suspend fun setGhost(mode: String, hours: Int?) {
        r("set_ghost", buildJsonObject { put("p_mode", mode); if (hours != null) put("p_hours", hours) })
    }
    suspend fun hidden(): List<String> = r("get_hidden").decodeList<HiddenRow>().map { it.hiddenUser }
    suspend fun setHidden(user: String, hidden: Boolean) {
        r("set_hidden", buildJsonObject { put("p_user", user); put("p_hidden", hidden) })
    }
    suspend fun updateLocation(lat: Double, lng: Double, acc: Float, speed: Float, battery: Int, charging: Boolean) {
        r("update_location", buildJsonObject {
            put("p_lat", lat); put("p_lng", lng); put("p_acc", acc)
            put("p_speed", speed); put("p_battery", battery); put("p_charging", charging)
        })
    }
    suspend fun familyLocations(): List<Loc> = r("get_family_locations").decodeList<Loc>()

    // SOS
    suspend fun startSos(lat: Double, lng: Double): String =
        r("start_sos", buildJsonObject { put("p_lat", lat); put("p_lng", lng) }).decodeAs<String>()
    suspend fun updateSos(lat: Double, lng: Double) {
        r("update_sos", buildJsonObject { put("p_lat", lat); put("p_lng", lng) })
    }
    suspend fun endSos() { r("end_sos") }
    suspend fun activeSos(): List<Sos> = r("get_active_sos").decodeList<Sos>()

    // calls
    suspend fun startCall(callee: String, kind: String): String =
        r("start_call", buildJsonObject { put("p_callee", callee); put("p_kind", kind) }).decodeAs<String>()
    suspend fun incomingCall(): IncomingCall? = r("get_incoming_call").decodeList<IncomingCall>().firstOrNull()
    suspend fun answerCall(id: String) { r("answer_call", buildJsonObject { put("p_call", id) }) }
    suspend fun declineCall(id: String) { r("decline_call", buildJsonObject { put("p_call", id) }) }
    suspend fun endCall(id: String) { r("end_call", buildJsonObject { put("p_call", id) }) }
    suspend fun callStatus(id: String): String = r("call_status", buildJsonObject { put("p_call", id) }).decodeAs<String>()
    suspend fun sendSignal(call: String, to: String, kind: String, payload: JsonObject) {
        r("send_signal", buildJsonObject {
            put("p_call", call); put("p_to", to); put("p_kind", kind); put("p_payload", payload)
        })
    }
    suspend fun signals(call: String, after: Long): List<Signal> =
        r("get_signals", buildJsonObject { put("p_call", call); put("p_after", after) }).decodeList<Signal>()
    suspend fun callHistory(): List<CallLog> = r("get_call_history").decodeList<CallLog>()

    suspend fun unread(): List<Unread> = r("get_unread").decodeList<Unread>()
}
