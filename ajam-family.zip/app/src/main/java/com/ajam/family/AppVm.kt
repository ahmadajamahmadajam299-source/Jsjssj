package com.ajam.family

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

enum class Stage { Loading, Welcome, Username, FamilyGate, Pending, Main }

data class ConvItem(val id: String, val title: String, val isGroup: Boolean)

fun friendly(e: Throwable): String {
    val m = e.message ?: ""
    return when {
        "username_taken" in m -> "اسم المستخدم محجوز، اختر اسماً آخر"
        "invalid_code" in m -> "كود العائلة غير صحيح"
        "rate_limited" in m -> "رسائل كثيرة بسرعة، انتظر قليلاً"
        "already_in_family" in m -> "أنت منضم لعائلة بالفعل"
        "UnknownHost" in m || "Unable to resolve" in m || "timeout" in m.lowercase() ->
            "تعذّر الاتصال بالإنترنت"
        else -> "حدث خطأ: " + m.take(160)
    }
}

class AppVm : ViewModel() {
    var stage by mutableStateOf(Stage.Loading); private set
    var busy by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null)
    var me by mutableStateOf<Profile?>(null); private set
    var members by mutableStateOf<List<Profile>>(emptyList()); private set
    var convs by mutableStateOf<List<ConvItem>>(emptyList()); private set
    var joinCode by mutableStateOf<String?>(null); private set
    var usernameOk by mutableStateOf<Boolean?>(null); private set
    var openChat by mutableStateOf<ConvItem?>(null); private set
    var messages by mutableStateOf<List<Message>>(emptyList()); private set

    init {
        viewModelScope.launch {
            try {
                Repo.awaitInit()
                if (!Repo.hasSession()) stage = Stage.Welcome else refreshInternal()
            } catch (e: Throwable) {
                if (e is CancellationException) throw e
                error = friendly(e)
                stage = Stage.Welcome
            }
        }
    }

    private fun launchSafe(block: suspend () -> Unit) = viewModelScope.launch {
        busy = true
        try {
            block()
        } catch (e: Throwable) {
            if (e is CancellationException) throw e
            error = friendly(e)
        } finally {
            busy = false
        }
    }

    private fun launchQuiet(block: suspend () -> Unit) = viewModelScope.launch {
        try { block() } catch (e: Throwable) { if (e is CancellationException) throw e }
    }

    private suspend fun refreshInternal() {
        val p = Repo.myProfile()
        me = p
        stage = when {
            p == null -> Stage.Welcome
            p.username == null -> Stage.Username
            p.status == "none" -> Stage.FamilyGate
            p.status == "pending" -> Stage.Pending
            else -> { loadMain(); Stage.Main }
        }
    }

    private suspend fun loadMain() {
        members = Repo.members()
        val cs = Repo.conversations()
        val ms = Repo.convMembers()
        val byId = members.associateBy { it.id }
        val myId = me?.id
        convs = cs.map { c ->
            val title = if (c.kind == "group") {
                c.name ?: "مجموعة"
            } else {
                val other = ms.firstOrNull { it.conversationId == c.id && it.userId != myId }
                byId[other?.userId]?.displayName ?: "محادثة"
            }
            ConvItem(c.id, title, c.kind == "group")
        }
        if (me?.role == "admin") joinCode = try { Repo.joinCode() } catch (e: Exception) { joinCode }
    }

    fun nameOf(id: String): String = members.firstOrNull { it.id == id }?.displayName ?: ""

    fun silentRefresh() { launchQuiet { refreshInternal() } }
    fun silentReload() { launchQuiet { me = Repo.myProfile(); loadMain() } }

    fun submitName(name: String) = launchSafe {
        Repo.ensureSession()
        Repo.createProfile(name.trim())
        refreshInternal()
    }

    fun resetUsernameCheck() { usernameOk = null }
    fun checkUsername(u: String) { launchQuiet { usernameOk = Repo.usernameAvailable(u) } }
    fun claimUsername(u: String) = launchSafe { Repo.claimUsername(u); refreshInternal() }

    fun createFamily(name: String) = launchSafe { Repo.createFamily(name.trim()); refreshInternal() }
    fun joinFamily(code: String) = launchSafe { Repo.joinFamily(code); refreshInternal() }

    fun approve(id: String) = launchSafe { Repo.approve(id); loadMain() }
    fun promote(id: String) = launchSafe { Repo.promote(id); loadMain() }
    fun remove(id: String) = launchSafe { Repo.remove(id); loadMain() }
    fun newCode() = launchSafe { joinCode = Repo.newJoinCode() }

    fun startDirect(userId: String) = launchSafe {
        val id = Repo.direct(userId)
        loadMain()
        openChat = convs.firstOrNull { it.id == id }
        messages = emptyList()
    }

    fun createGroup(name: String, ids: List<String>) = launchSafe {
        val id = Repo.createGroup(name.trim(), ids)
        loadMain()
        openChat = convs.firstOrNull { it.id == id }
        messages = emptyList()
    }

    fun open(c: ConvItem) { openChat = c; messages = emptyList() }
    fun closeChat() { openChat = null }

    fun pollMessages() {
        val c = openChat ?: return
        launchQuiet { messages = Repo.messages(c.id) }
    }

    fun send(text: String) {
        val c = openChat ?: return
        val myId = me?.id ?: return
        val t = text.trim()
        if (t.isEmpty()) return
        viewModelScope.launch {
            try {
                Repo.send(c.id, myId, t)
                messages = Repo.messages(c.id)
            } catch (e: Throwable) {
                if (e is CancellationException) throw e
                error = friendly(e)
            }
        }
    }

    fun saveProfile(name: String, bio: String) = launchSafe {
        val id = me?.id ?: return@launchSafe
        Repo.updateProfile(id, name.trim(), bio.trim())
        me = Repo.myProfile()
    }
}
