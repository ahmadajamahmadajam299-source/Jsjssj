package com.ajam.family

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private lateinit var sp: SharedPreferences
    fun init(c: Context) { sp = c.getSharedPreferences("ajam", Context.MODE_PRIVATE) }
    var tourDone: Boolean
        get() = sp.getBoolean("tour_done", false)
        set(v) { sp.edit().putBoolean("tour_done", v).apply() }
}
